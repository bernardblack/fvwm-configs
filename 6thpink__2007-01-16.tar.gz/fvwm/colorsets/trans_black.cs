#################
# Colorsets 1 y 2
#################
# + TitleStyle AllActive Colorset 1
# + TitleStyle AllInactive Colorset 2
#####################################
Colorset   1 bg black, VGradient 24 3 white 1 grey15 98 grey60 1 black
Colorset   2 bg black, VGradient 24 3 white 1 grey30 98 grey60 1 black
# 1.- bg - barra de título activa, en decos planas solo!
# 2.- bg - barra de título inactiva, en decos planas solo!

#################
# Colorsets 3 y 4
#################
# Style * Colorset 3
# Style * HilightColorset 4
###########################
Colorset   3 bg grey50, fg grey75, sh black, fgsh black
Colorset   4 bg grey70, fg white, sh black, fgsh black
# 3.- bg barra de títulos y borde, ventana inactiva
# 4.- bg barra de títulos y borde, ventana activa
# 4.- sh - color de sombra en símbolos si @0
# fgsh color de sombra del texto, por fin doy con él!! :P

# FvwmForm-QV
Colorset   5 bg grey80, DGradient 128 white grey80, fg black, hi grey70, sh grey70

#Panel
Colorset   6 RootTransparent, Tint black 30, bg black, hi grey40

# Menú, selección
Colorset   7 bg #C04000, fg white, sh grey80, hi grey80
# Menú, fondo
Colorset   8 Translucent black 80, bg black, fg white, sh grey40, hi grey40
#Pager, fondo escritorio inactivo
Colorset   9 bg black, VGradient 48 black grey9, fg white, sh grey80, hi white
#Pager, fondo escritorio activo
Colorset  10 bg white, fg grey60
#Pager, ventana inactiva
Colorset  11 bg grey80
#Pager, ventana activa
Colorset  12 bg white

#FvwmIconMan, default
Colorset  13 bg black, Transparent, fg grey70, sh grey70, hi grey70
#FvwmIconMan, seleccionado y foco-seleccionado
Colorset  14 bg black, Transparent, fg grey70, sh grey70, hi grey70
#FvwmIconMan, foco
Colorset  15 bg #C04000, fg white, sh grey80, hi grey80


#!/bin/bash
# Note to self:
# Make sure that no output is send to stdout
# only stuff that fvwm can digest is allowed
# Just echo the rest with \# in front of the line

test ! -d "${FVWM_USERDIR}/wallpapers/.thumbs" \
	&& mkdir -p ${FVWM_USERDIR}/wallpapers/.thumbs

# Check the contents of .menu_thumb_size to see
# wether it is a valid factor or any other thing

menuthumbsize=$(grep -x '[0-9]*x[0-9]*' \
	${FVWM_USERDIR}/.menu_thumb_size)

if [[ -n ${menuthumbsize} ]]
then
	for i in ${FVWM_USERDIR}/wallpapers/*
	do \
		echo \# 
		if [[ -f "${FVWM_USERDIR}/wallpapers/.thumbs/$(basename ${i}.png)" && \
			-f "${i}" ]]
		then
			i_size=$(identify -verbose "${FVWM_USERDIR}/wallpapers/.thumbs/$(basename ${i}.png)" | grep Geometry | sed -e 's/  Geometry: //')
			echo \#
			echo \# Image size = \"${i_size}\", wanted size = \"${menuthumbsize}\"
			if [[ "${menuthumbsize}" == "${i_size}" ]]
			then
				: # Fallback
				echo \# NOP
				echo "+ $(basename ${i})%${FVWM_USERDIR}/wallpapers/.thumbs/$(basename ${i}.png)% user_ChangeWallpaper ${i}"
				continue
			fi
		fi
		convert -scale ${menuthumbsize}! "${i}" "png:${FVWM_USERDIR}/wallpapers/.thumbs/$(basename ${i}).png" && \
		echo \# ${i} thumbnailed.
		echo "+ $(basename ${i})%${FVWM_USERDIR}/wallpapers/.thumbs/$(basename ${i}.png)% user_ChangeWallpaper ${i}"
	done
else
	# Reseting contents of .menu_thumb_size to 32x24
	echo # .menu_thumb_size corrupt!!!
	echo # Reseting contents of .menu_thumb_size to 32x24
	echo 32x24 > ${FVWM_USERDIR}/.menu_thumb_size
	# And reruns itself
	$0
fi

exit 0

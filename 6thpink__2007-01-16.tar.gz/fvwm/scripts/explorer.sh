#!/bin/bash

if [[ -n $1 && -d $1 ]]
then
  echo DestroyMenu recreate $1
  echo AddToMenu $1
  echo + DynamicPopDownAction DestroyMenu $1
  echo + MissingSubmenuFunction user_FileBrowser
  echo + \"Abrir terminal%terminal.png%\" Exec exec urxvt -e bash -c cd ${1}
  echo + \"Explorar carpeta%konqueror.png%\" Exec exec konqueror --profile filemanagement $1
  echo + \"Abrir en filelight%filelight.png%\" Exec exec filelight $1
  echo + \"Galería de imágenes%gwenview.png%\" Exec exec gwenview $1
  echo + \"\" Nop
  for i in ${1}/*
  do \
    if [[ -d "${i}" ]]
	then
      echo + \"$(basename "${i}")%folder.png%\" Popup "${i}"
      continue
    fi
  done
fi

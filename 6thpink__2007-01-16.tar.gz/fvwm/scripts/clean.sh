rm -f $(find . -name "*~")
rm -f $(find . -name "magick*")
rm -f .FvwmConsole-History

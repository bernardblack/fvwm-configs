#!/usr/bin/perl -w

use lib `fvwm-perllib dir`;
use FVWM::Module;
chdir;
my $ConfigFile = ".fvwm/trans_focus.exclude";

my $module = new FVWM::Module(
   Mask => M_FOCUS_CHANGE | M_ADD_WINDOW,
);

$module->addHandler(M_FOCUS_CHANGE, \&FocusWindow);
$module->addHandler(M_ADD_WINDOW, \&CollectInfo);
my $prev_win = 0;

open(CONFIG, $ConfigFile) || die ("Could not open file");
@exclude_file = <CONFIG>;
close(CONFIG);

sub FocusWindow
{
   my ($module, $event) = @_;
   my $id = 0;
   my $found = 0;
   if($prev_win)
   {
      foreach $id (@EXCLUDE_ID)
      {
         if($id == $prev_win)
         {
            $found = 1;
            last;
         }
      }
      if(!$found)
      {
         my $cmd = "transset-df -i " . $prev_win . " .8 " ;
         system($cmd);
      }
   }
   $prev_win = $event->_win_id;
   my $cmd = "transset-df -i " . $prev_win . " 1.0 ";
   system($cmd);
   $found = 0;
}

sub CollectInfo
{
    my ($module, $event) = @_;
    my $win_id = $event->_win_id;
    my $line;
    foreach $line (@exclude_file)
    {
        chomp($line);
        my @tokens = split(/:/, $line);
        my $test = "xprop -id " . $win_id . " | grep " . $tokens[0];
        my $result = `$test`;
        if($result =~ m/$tokens[1]/)
        {
            push(@EXCLUDE_ID, $win_id);
            return;
        }
    }
}
   
$module->eventLoop; 

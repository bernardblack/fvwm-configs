#!/usr/bin/perl

use lib `fvwm-perllib dir`;
use FVWM::Module;

my $module = new FVWM::Module;

# Get to the right directory;
chdir;
my $configFile = ".fvwm/trans.defaults";

# Called by FVWM
sub callback
{
    my $win_id = $_[1]->_win_id;
    my $trans = 1.0;
    open(DEFAULTS, "<", $configFile);

    while(my $line = <DEFAULTS>)
    {
        # Token 0 is the window property to match against
        # Token 1 is the value to match
        # Token 2 is the default transparency level
        chomp($line);
        my @tokens = split(/:/, $line);
        my $test = "xprop -id " . $win_id . " | grep " . @tokens[0];
        my $result = `$test`;
        if($result =~ m/@tokens[1]/)
        {
            $trans = @tokens[2];
        }
    }

    if($trans < 1.0)
    {
        # why sleep 0.5? do it now!
        my $cmd = "transset-df -i " . $win_id . " " . $trans;
        system($cmd);
    }
}

$module->addHandler(M_ADD_WINDOW, \&callback);
$module->eventLoop;


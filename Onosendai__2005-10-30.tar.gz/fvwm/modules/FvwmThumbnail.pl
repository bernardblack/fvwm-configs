#! /usr/bin/perl -w
#
# FvwmThumbnail: A thumbnailing module for FVWM
# To create the man page:
# pod2man FvwmThumbnail.pl | gzip -c > FvwmThumbnail.1.gz
# cp FvwmThumbnail.1.gz /usr/share/man/man1/
#
use strict;
use lib `fvwm-perllib dir`;
use FVWM::Module;
use Symbol;
use Image::Magick;
use Class::Struct;
use Data::Dumper;
use Text::ParseWords;

$::SIG{PIPE} = sub { die "Module Shutdown\n" };

#
# A scaling class defines a set of thumnails for a specific purpose.
# you could define a scaling class to use for application icons,
# another for mini-icons, and another for big mini-icons for a big pager
#
# we do it this way because we already have the image data for the
# window - it's more efficient to scale that data into multiple images
# than it is to read it multiple times with multiple module instances
#
# name		names the class and defines the directory where the icons live
# image_sub	reference to a subroutine to render the image. it gets passed
#		the image, ScaleClass object, the page tracker and the
#		module object.
# factor_{x,y}	scaling factors. If factor_y is missing, factor_x is used for
#		both. If both are missing they get calculated from to_x and to_y
# to_x, to_y	the image will be scaled to fit in a box to_x by to_y
#		this will break aspect ratio if the to_x:to_y ration is not the
#		same as your viewport, but it allows me to scale a letterbox
#		window into a square pager
# command	commands to send back to fvwm after processing is done.
#		any %w will expand to the window id; any %i will expand
#		to the full path of the icon file
#
struct(
	ScaleClass => [
		name		=> '$',
		image_sub	=> '$',
		to_x		=> '$',
		to_y		=> '$',
		factor_x	=> '$',
		factor_y	=> '$',
		command		=> '@',
		overlay_flag	=> '$',
		overlay_x	=> '$',
		overlay_y	=> '$',
	]
);

#
# A list of global stuff for the module
#
struct(
	FvwmThumbnail => [
		module		=> 'FVWM::Module',	# the module instance
		dir		=> '$',			# where the icons live
		current		=> '$',			# last imaged window
		win_list	=> '$',			# winlist tracker
		page_track	=> '$',			# winlist tracker
		skip_list	=> '$',			# don't image these
		scheduler	=> '$',			# schedule tracker
		config		=> '$',			# module config tracker
		scale_classes	=> '%',			# ScaleClass objects
		refresh		=> '$',			# refresh frequency
		mode		=> '$',			# manual or automatic
		thumb_events	=> '@',			# to trigger thumbs
		delete_events	=> '@',			# to trigger deletion
		debug		=> '$',			# enable debug chatter
		overlay_flag	=> '$',			# if true for any class
	]
);

#
# module data instance
#
my $mdata;
sub default_image_sub($$$$);

my %mini_icon_images = ();

my @dir_list = ();

sub set_dir_list
{
	my $module = shift;
	my $globals = $module->track("GlobalConfig");
#
#       we extract the image path from the tracker
#
	my $image_path = $globals->data->{'ImagePath'};
#
#       split the path into component directories and store the list 
#
	@dir_list = split /:/, $image_path;
#
#       should never happen
#
	die "no image path" unless scalar( @dir_list );
}

sub find_image
{
	my $file = shift;
#
#       return the file name if it starts with a slash
#
	return $file unless $file;
	return $file if $file =~ m[^/];
	return $file if $file =~ /^ewmh_mini_icon$/;
#
#       search image path for file
#
	for my $dir ( @dir_list ) {
		next unless -f "$dir/$file";
		return "$dir/$file";
	}
	die "$file not found in @dir_list\n";
	return undef;
}

sub debug
{
	return unless $mdata->debug;
	print "### DEBUG: ";
	print shift;
}

sub parse_event_list
{
	my $raw = uc(shift);
#
#	this needs commas as separators. we may already have them
#
	$raw =~ s/[\s,]+/, /g;
#
#	now add M_ to the start of all the strings
#
	$raw =~ s/(\w+)/M_$1/g;
#
#	a bit of debug so we can check its behaving itself
#
	#print "raw event list = $raw\n";
#
#	and construct a list reference
#
	my $lref = eval "[ $raw ]";
	die $@ if $@;
	die "lref undefined" unless defined $lref;
	return $lref;
}

#
# process scale class definitions from the config file
#
sub process_scale_class
{
	my $text = shift;
#
#	chop off the "Class Foo, " bit, get value of "Foo"
#
	$text =~ s/
		\s* Class \s+		# literal class + whitespace
		(\w+)			# the class name goes into dollar 1
		\s* ,? \s*		# whitespace, optional comma
	//x;
	my $name = $1;
	#print "Class Name: $name\n";
#
#	look up class name, create a new one if need be
#
	my $scaler;
	$scaler = $mdata->scale_classes($name) || do {
#
#		couldn't find scale class $name: create it
#
		$mdata->scale_classes(
			$name, ScaleClass->new(
				name		=> $name,
				overlay_flag	=> 0,
			)
		);
	};
#
#	if there is nothing else to parse, return
#
	return unless $text;
#
#	OK then, let's split what's left into tokens
#
	my @tokens = quotewords('\s*,{0,1}\s+', 0, $text);
#
#	loop through the tokens: they should be (command,argument) pairs
#
	while(my ($cmd, $arg) = splice(@tokens, 0, 2)) {
		local $_ = $cmd;
#
#		scaleTo takes a geometry string
#
		/^ScaleTo/i and do {
			$arg =~ /(\d+)x(\d+)/;
			$scaler->to_x($1);
			$scaler->to_y($2);
			#printf("ScaleTo: %dx%d\n",$scaler->to_x,$scaler->to_y); 
			next;
		};
#
#		push the command onto the command list
#
		/^Command/i and do {
			push(@{ $scaler->command }, $arg);
			next;
		};

		/Overlay/i and do {
			unless($arg =~ /\+(\d+)\+(\d+)/) {
				$mdata->module->showError(
					"can't parse overlay geometry '$arg'"
				);
				next;
			}
			$scaler->overlay_flag(1);
			$mdata->overlay_flag(1);
			$scaler->overlay_x($1);
			$scaler->overlay_y($2);
			next;
		};
#
#		scaling factors: two floats with an "x" in the middle
#
		/^Factor/i and do {
			my ($x,$y) = split /x/, $arg;
			$y = $x unless $y;
			$scaler->factor_x($x);
			$scaler->factor_y($y);
			next;
		};
#
#		define a user subroutine to generate the icon
#
		/ImageSub/i and do {
			my $coderef = eval "sub { $arg }";
			do {
				print STDERR "error in ImageSub: '$arg'\n";
				die $@
			} if $@;
			$scaler->image_sub($coderef);
			next;
		};
#
#		anything else may be a syntax error
#		or else something I forgot to implement. there's still
#		a bunch of stuff to do here...
#
		print "process_scale_class: Unrecognised: $cmd $arg\n";
	}
}

sub process_skip_list
{
	my $raw = shift;
	$raw =~ s/\*/.*/g;
	debug "raw skip list = $raw\n";
	my @tokens = quotewords('\s+', 0, $raw);

	my $pattern = "";
	for my $tok (@tokens) {
		debug "	token = $tok\n";
		$pattern .= "^$tok\$|";
	}
	chop $pattern;
	debug "cooked skip list = $pattern\n";
	$mdata->skip_list($pattern);
}

#
# process the module lines from the config
#
sub process_config
{
	my $lref = $mdata->config->data;
#
#	loop through the elements in the list reference
#
	for (@$lref) {
		/^Mode/i and do {
			my $mode = lc((split)[1]);
			$mode =~ /manual|auto/i or do {
				print "unexpected mode '$mode'. using 'auto'\n";
				$mode = "auto";
			};
			#print "mode: $mode\n";
			$mdata->mode( $mode );

			next;
		};
		/^Refresh/i and do {
			$mdata->refresh( (split)[1]);
			#print "refresh time: ${ \($mdata->refresh) }\n";
			next;
		};
		/^Directory/i and do {
			$mdata->dir( (split)[1]);
			#print "using ${ \($mdata->dir) }\n";
			next;
		};
		/^Class/i and do {
			process_scale_class($_);
			next;
		};
#
#		this allows the user to specify which events trigger
#		thumbnailing. format is a list of events in the FvwmEvent format
#
		/^GenerateOn/i and do {
			/\s+(.*)/;
			my $lref = parse_event_list($1);
			$mdata->thumb_events($lref);
			next;
		};
		/^DeleteOn/i and do {
			/\s+(.*)/;
			my $lref = parse_event_list($1);
			$mdata->delete_events($lref);
			next;
		};

		/^SkipList\s+(.*)$/i and do {
			process_skip_list($1);
			next;
		};

		/^Debug\s+(\d+)$/i and do {
			$mdata->debug($1);
			debug sprintf("Debug Level set to %s\n", $mdata->debug);
			next;
		};

		print "process_config: Unrecognised: $_\n";
	}
}


sub get_factors
{
	my $scaler = shift;
#
#	we get called if there is no y co-ordinate.
#	if a x factor is supplied, use that for y as well
#
	if($scaler->factor_x) {
		$scaler->factor_y( $scaler->factor_x );
		return;					# Job Done!
	}
#
#	the remaining possibilities are to calculate factors from to_x and to_y
#	to let a user supplied image_sub handle the scaling in its own way
#	or to die complaining.
#
#	The calculation is the complicated bit. Let's do the easy ones first
#
	unless($scaler->to_x) {
		die "don't know how to scale for " . $scaler->name 
			unless $scaler->image_sub
		;
#
#		ok - the user is going to handle scaling 
#		set a y factor so we don't keep testing
#
		$scaler->factor_y(1);	# so we don't do this every time
		return if $scaler->image_sub;
	}

	my $pager = $mdata->page_track->data;
	#print Dumper $pager;
	my $vp_width = $pager->{ vp_width };
	my $vp_height = $pager->{ vp_height };

	debug "vp: height=$vp_height, width=$vp_width\n";

	$scaler->factor_x( $scaler->to_x / $vp_width );
	$scaler->factor_y( $scaler->to_y / $vp_height );
}

sub gen_thumb
{
	my $err;
	my $win_id = shift or return;

	$win_id =~ /^0x/ and $win_id = hex( $win_id );

	$mdata->current($win_id);

	my $image = new Image::Magick;  # image object
	my $pipe = gensym();
	my $cmd = sprintf("xwd -silent -id %s 2> /dev/null |", $win_id);
#
#       read the image from the pipe and then close the pipe
#
	#print "cmd = $cmd\n";
	open $pipe, $cmd or die "can't open pipe $!";
	$err = $image->Read(file => $pipe);
	unless(close $pipe) {
		if($! == 0) {
			printf "xwd exited with status $? for window $win_id\n";
			return;
		}
		print "error reading image: $!\n";
		return;
	}
#
#	check for errors
#
	if($err) {
		print "FvwmThumbnail: $err\n";
		return;
	}
#
#	now loop through each of the scale classes
#
	for my $k (keys %{ $mdata->scale_classes } ) {
		my $v = $mdata->scale_classes( $k );
		#print "Class $k, $v:\n";
		last unless $k;
#
#		construct the file name
#
		my $filename = sprintf("%s/%s/0x%x.png", 
			$mdata->dir, $v->name, $win_id
		);
#
#		check we have scaling factors
#
		unless($v->factor_y) {
			get_factors($v);
		}
#
#		call the sub to construct the image
#
		my $clone = $image->clone();
		if($v->image_sub) {
			$v->image_sub->($filename, $clone, $v, $win_id);
		}
		else {
			default_image_sub($filename, $clone, $v, $win_id);
		}
#
#		send any FVWM commands to the window manager
#
		for(@{ $v->command } ) {
			my $fvwm = $_;			# copy the string
			$fvwm =~ s/%w/$win_id/g;	# substitute %w
			$fvwm =~ s/%i/$filename/g;	# substitute %i
			$mdata->module->send($fvwm);
			#print "sent: $fvwm\n";
		}
	}
}


#
# expects to be called with a pre-scaled image
#
sub do_composite
{
	my $image = shift;
	my $sc_class = shift;
	my $wid = shift or die "usage: do_composite image class window-id";
#
#	now get the image of the mini-icon
#
	my $mini = $mdata->win_list->data($wid)->{ orig_mini_icon_image };

	unless($mini) {
		$mdata->module->showMessage("do_composite: no mini-image");
		return $image;
	}


	my $ret = $image->Composite(
		image		=> $mini, 
		compose		=> "atop",
		gravity		=> "NorthWest",
		x		=> $sc_class->overlay_x,
		y		=> $sc_class->overlay_y,
	);

	$image;

}

sub default_image_sub($$$$)
{
	my $rc;
	my $filename	= shift;
	my $image	= shift;
	my $scaler	= shift;
	my $wid		= shift;
#
#       now let's get the size of the image
#
	my ($cols, $rows) = $image->Get qw(base-columns base-rows);
	unless(defined $cols) {
		return;
	}
	$rc = $image->Resize( 
		height  => ($rows * $scaler->factor_y),
		width   => ($cols * $scaler->factor_x),
	);
	print "ERROR $rc\n" if $rc;
	$rc = $image->Frame(geometry => "2x2");
	print "ERROR $rc\n" if $rc;
        $rc = $image->Set(
		mattecolor      => "black",
		quality         => 0
	);
	print "ERROR $rc\n" if $rc;
#
#	if a composite flag is set, overlay the original mini-icon over
#	the window thumbnail
#
	if($scaler->overlay_flag) {
		$image = do_composite($image, $scaler, $wid);
	}

	$rc = $image->Write(filename => $filename);
	print "ERROR $rc\n" if $rc;
	#print "image written to $filename\n";
}

sub do_screenshot
{
	my $filename = shift;
	my $cmd = sprintf("xwd -silent -root 2> /dev/null |");
#
#	create an image object and a blank filehandle
#
	my $pipe = gensym();
	my $image = new Image::Magick;  # image object
#
#	open a pipe to xwd and read the image into an Image object
#
	open $pipe, $cmd or die "can't open pipe $!";
	$image->Read(file => $pipe);
	close $pipe;
#
#	write out the image to the file specified
#
	$image->Write(filename => $filename);
}

sub do_winshot
{
	my $win_id = shift;
	my $filename = shift;
	debug "do_winshot: $win_id $filename\n";
	$win_id =~ /^0x/ and $win_id = hex( $win_id );
	my $cmd = sprintf("xwd -silent -id %d 2> /dev/null |", $win_id);
#
#	create an image object and a blank filehandle
#
	my $pipe = gensym();
	my $image = new Image::Magick;  # image object
#
#	open a pipe to xwd and read the image into an Image object
#
	open $pipe, $cmd or die "can't open pipe $!";
	$image->Read(file => $pipe);
	close $pipe;
#
#	write out the image to the file specified
#
	$image->Write(filename => $filename);
}

sub string_h
{
	my $mod = shift;
	my $ev = shift;
	my $text = $ev->{ args }{ text };
#
#	not sure why I'm getting scheduler messages here, but...
#
	return if $text =~ /FVWM::Tracker::Scheduler/;
#
#	WinShot = take a window, store it in the file specified
#
	$text =~ /^WinShot\s+(\S+)\s+(\S+)/i and do {
		do_winshot($1, $2);
		return;
	};
#
#	Screenshot = take a screeny, store it in the file specified
#
	$text =~ /^ScreenShot\s+(.*)/i and do {
		do_screenshot($1);
		return;
	};
#
#	Thumbnail forces a thumbnail of the specified window
#
	$text =~ /^Thumbnail\s+(.*)/i and do {
		my $wid = $1;
		debug "Thumnail requested for '$wid'\n";
		gen_thumb($wid);
		return;
	};
#
#	The "Apply" command is last. Add any new commands before this point
#
	$text !~ /^Apply/i and do {
		print "unrecognised M_STRING: $text\n";
		return;
	};
#
#	Apply takes an FVWM command and a scaling class and applies the
#	command to all the icons in the scaling class.
#
#	Start by parsing the string
#
	$text =~ s/
		Apply \s+
		(\w+) \s+
		(.*)
	//xi or die "FvwmThumnail: unexpected STRING: " .
		$ev->{ args}{ text }
	;
#
#	Look up the scale class
#
	my $class = $mdata->scale_classes($1);
	my $command = $2;
#
#	now - loop through the windows, applying the remaining text to
#	each in turn
#
	my $dir = sprintf("%s/%s", $mdata->dir, $class->name);
	for my $file (<$dir/*>) {
		debug "file = $file\n";
		my $id = $file;
		$id =~ s/.png//;
		$id =~ s!.*/!!;
		debug "id = $id\n";
#
#		copy the command before we change it
#
		my $copy = $command;
		$copy =~ s/%w/$id/g;		# substitute %w
		$copy =~ s/%i/$file/g;	# substitute %i
#
#		send it to fvwm
#
		debug "command = $copy\n";
		$mdata->module->send($copy);
	}
}

sub destroy_h
{
	my $mod = shift;
	my $ev = shift;
	my $win_id = $ev->argValues->[0];

	for my $sc (values %{ $mdata->scale_classes }) {
		unlink sprintf("%s/%s/0x%x.png", 
			$mdata->dir, $sc->name, $win_id
		);
	}
}

sub check_names
{
	my $pattern = shift;
	my $win = shift;

	return 0 unless $pattern;
	for my $k (qw(name res_name res_class_name)) {
		next unless $win->{ $k };
		debug "$k = " . $win->{ $k } . "\n";
		$win->{ $k } && $win->{ $k } =~ /$pattern/o && return 1;
	}
	return 0;
}

sub thumbnail_h
{
	my $module = shift;
	my $ev = shift;
	my $win_id = $ev->argValues->[0];
	my $now = time;
#
#	is this a new window? If not, have we done it recently?
#
	my $win_data = $mdata->win_list->data($win_id);
	my $stamp = $win_data->{ timestamp };
	if($stamp && ($now - $stamp) < 5) {
		return;
	}
#
#	check name, resource name and resource class name against
#	the skip list
#
	#print Dumper $win_data;
	if($mdata->skip_list && check_names($mdata->skip_list, $win_data)) {

		debug sprintf("winlist matched: skipping %s/%s/%s\n",
			$win_data->{ name },
			$win_data->{ res_name },
			$win_data->{ res_class_name }
		);
		return;
	}
#
#	this is a bit naughty - the winlist hash isn't really ours to modify
#
	$win_data->{ timestamp } = $now;
#
#	now - we may need to preserve the original mini icon and generate an
#	image object from it.
#
#	before we get into all that, let's make sure it's necessary
#
	return unless $mdata->overlay_flag;
	return if $win_data->{ orig_mini_icon_name };
	my $filename = find_image($win_data->{mini_icon_name});
	return unless $filename;
	return if $filename =~ /^ewmh_mini_icon$/;;
	return if $filename =~ /0x\d+\.png/;
#
#	a bit of chatter, help see what's happening...
#
	$module->debug("preserving '$filename'\n");
	$win_data->{ orig_mini_icon_name } = $filename;
#
#	create a new Image object
#
	my $image = Image::Magick->new();  # image object
	my $rc = $image->Read(filename => $filename);
	print "ERROR: $rc" if $rc;
#
#	and since we're already playing silly buggers with the winlist...
#
	$win_data->{ orig_mini_icon_image } = $image;
#
#	last of all, the thumbnail
#
	gen_thumb($win_id);
}

sub main
{
	my $mask	= M_ADD_WINDOW | M_FOCUS_CHANGE | M_RAISE_WINDOW 
			| M_STRING | M_DESTROY_WINDOW
			;
	my $module = FVWM::Module->new(
		Mask 	=> $mask,
		Debug	=> 0,
	);
	$module->addDefaultErrorHandler;
	set_dir_list($module);
#
#	$mdata gathers all our global data 
#
	$mdata = FvwmThumbnail->new(
		dir		=> "$ENV{FVWM_USERDIR}/.thumbnails.tmp",
		mode		=> "auto",
		module		=> $module,
		scheduler	=> $module->track('Scheduler'),
		win_list	=> $module->track('WindowList', "stack icons names winfo"),
		page_track	=> $module->track('PageInfo'),
		config 		=> $module->track("ModuleConfig",
			ConfigType => "array"
		),
		refresh		=> 5,
		thumb_events	=> [	M_ADD_WINDOW, M_FOCUS_CHANGE,
					M_RAISE_WINDOW 
				   ],
		delete_events	=> [ 	M_DESTROY_WINDOW ],
		overlay_flag 	=> 0,
	);
#
#	process config data from fvwm
#
	process_config();
#
#	create a temp dir for the icon files
#
	#printf "storing icons in %s\n", $mdata->dir;
	mkdir $mdata->dir;
	for my $c ( values %{ $mdata->scale_classes } ) {
		mkdir $mdata->dir . "/" . $c->name;
	}
#
#	Now: we want to catch a few events
#
	if($mdata->mode !~ /manual/) {
		for my $ev (@{ $mdata->thumb_events }) {
			$module->addHandler($ev, \&thumbnail_h);
		}
	}

	for my $ev (@{ $mdata->delete_events }) {
		$mdata->module->addHandler($ev, \&destroy_h);
	}

	$mdata->module->addHandler(M_STRING, \&string_h);
#
#	every few seconds, update the pic of the current window
#
	#printf("refresh time = %d\n", $mdata->refresh);
	$mdata->refresh && $mdata->scheduler->schedule(
		$mdata->refresh, sub {
			return unless $mdata->current;
			#printf("Refresh: 0x%x\n", $mdata->current);
			gen_thumb($mdata->current);
			$mdata->scheduler->reschedule;
		}
	);

	$mdata->module->eventLoop;
}

main();

__END__



=head1 NAME

FvwmThumbnail - Generate thumbnails of windows suitable for use as icons

=head1 SYNOPSIS

DestroyModuleConfig FvwmThumbnail: *

 *FvwmThumbnail: Refresh 5

 *FvwmThumbnail: Class Pager, ScaleTo 27x27
 *FvwmThumbnail: Class Pager, Command "WindowId %w WindowStyle EWMHMiniIconOverride, MiniIcon %i"

 *FvwmThumbnail: Class Icons, Factor 0.2x0.2
 *FvwmThumbnail: Class Icons, Command "WindowId %w WindowStyle IconOverride, Icon %i"

 AddToFunc StartFunction + I Module FvwmThumbnail 

FvwmMonitor  can  only  be invoked by fvwm.  Command line invocation of
the FvwmMonitor module will not work.

=head1 DESCRIPTION

FvwmThumbnail takes snpashots of the current window, scales and stores them
for use as icons. Multiple sets of differently scaled icons (called scaling classes) are supported. Once image, images of the the current window are automatically updated at regular intervals

The scaling process is more efficient than using pipereads, since 
once the window image has been read, all the processing happens in-process using the Image::Magick interface. In addition, if multiple image sets are being maintained, the raw image data only needs to be read once.

=head1 MODULE CONFIGURATION COMMANDS

=over 4

=item B<Refresh> I<interval>

Tells FvwmThumnail to update the current window icons every
I<interval> seconds. Set to zero to disable auto-update.

=item B<Directory> I<path>

Tells FvwmThumnail to store the icons in directory I<path>. The actual files
will be created in sub-directories based on scaling class name,

=item B<Mode> B<Manual>|B<Auto> [ I<class-config-commands> ]

Manual mode will not take any thubnails on events. Auto mode will. The default 
is Auto.

=item B<GenerateOn> I<event-list>

This specifies the events that will cause FvwmThumbnail to take a thumbnail of
a window. Events are in the format used by FvwmEvent. eg:

	*FvwmThumbnail: GenerateOn raise_window

=item B<DeleteOn> I<event-list>

Similar to GenerateOn but specifies the events that cause deletion of
icon files

	*FvwmThumbnail: DeleteOn destroy_window, windowshade, iconify

=item B<Class> I<name> [ I<class-config-commands> ]

Defines a scaling class called I<name>. Any commands that follow on the same line are used to configure the named class.

Class definitions are additive. Thus: 

 *FvwmThumbnail: Class Pager
 *FvwmThumbnail: Class Pager, ScaleTo 27x27
 *FvwmThumbnail: Class Pager, Command "WindowId %w WindowStyle EWMHMiniIconOverride, MiniIcon %i"

is the same as 

 *FvwmThumbnail: Class Pager, ScaleTo 27x27 \
	 Command "WindowId %w WindowStyle EWMHMiniIconOverride, MiniIcon %i"


Choose whichever style you find easiest to read.

=back

=head1 SCALING CLASS CONFIGURATION COMMANDS


These commands only work if they follow a Class command on the same line.
The command defines the behaviour of the class, rather than the module
as a whole

=over 4

=item B<Factor> I<scaling-factor> 

=item B<Factor> I<geometry> 

With a single scaling factor, both axes are scaled similarly.  The geometry
format (XxY) allows the two axes to be scaled separately 

=item B<ScaleTo> I<geometry> 

The ScaleTo option calculates the scaling factors needed to scale the viewport 
onto the specified geometry. This is useful if, like the author, you have a letter box format display and a square pager.

=item B<Overlay> I<geometry> 

If a window has a mini-icon defined initially, this command directs FvwmThumbnail to composite all images in this scaling class with the mini-icon image.

The image is placed in the top left corner of the icon. Setting geometry values will adjust the location.

=item B<Command> I<fvwm-command> 

Tells the module to send I<fvwm-command> to FVWM after a window is scaled. 
In the command %w will be expanded to the window id of the window, while %i 
will expand to the full path of the icon file.

Multiple commands may be specified by invoking Command multiple times.

=item B<ImageSub> I<perl-commands> 

Defines a subroutine to generate the icon file. The argument should
be a sequence of Perl statements which will to be enclosed in a "sub {
.... }" construct and passed to the I<eval> command.

The resulting subroutine is called with three arguments: the fileame to 
write the icon data to; the Image data; and the relevant ScaleClass object.
ScaleClass has the following methods:

	name		# name of the ScaleClass
	image_sub	# user defined perl sub to render image; may be null
	to_x		# x dimension of box to scale image to
	to_y		# ditto for y
	factor_x	# x scaling factor. 
	factor_y	# y scaling factor. 
	command		# array ref of FVWM commands

=back


=head1 SEND-TO-MODULE COMMANDS

FvwmThumbnail accepts a number of commands via the SendToModule interface:

=over 4

=item B<Apply> I<ScaleClass> I<fvwm-commands>

Applies fvwm-command to all windows. %i and %w are subsituted as above

=item B<Apply> B<Thumbnail> I<win-id>

Creates a thumbnail of the specified window for each scaling class defined.

=item B<Apply> B<ScreenShot> I<filename>

Generates a 100% screenshot and writes it to I<filename>. The file suffix
determines file format.

=item B<Apply> B<WinShot> I<win-id> I<filename>

Snaps the specified window and writes it full size to the I<filename>. The file
suffix determines the image format.

=back

=head1 EXAMPLE

This is the configuration I use on my laptop:

    DestroyModuleConfig FvwmThumbnail: *

    *FvwmThumbnail: Debug 0			# no debug messages
    *FvwmThumbnail: Mode Auto		# automatically take thumbs
    *FvwmThumbnail: Refresh 0		# don't update automatically
    #
    # set the thumbnail directory 
    #
    *FvwmThumbnail: Directory /home/nick/lab/fvwm_thumbs
    #
    # don't thumnail my panel or taskbar
    #
    *FvwmThumbnail: SkipList Klix FvwmIconMan
    #
    # Icons for minimised windows - scaled to one fifth size
    #
    *FvwmThumbnail: Class Icons, Factor 0.2x0.2
    *FvwmThumbnail: Class Icons, Overlay +8+4
    *FvwmThumbnail: Class Icons, Command \
 	   "WindowId %w WindowStyle IconOverride, Icon  %i"
    #
    # My desktop has a 1280x800 aspect ratio, but my pager is square
    # so scale the mini-icons to a 27x27 pixel square
    #
    *FvwmThumbnail: Class Pager, ScaleTo 27x27
    *FvwmThumbnail: Class Pager, Command \
 	   "WindowId %w WindowStyle EWMHMiniIconOverride, MiniIcon %i"
    #
    # Generate thumbs on raise events, delete icon files on window 
    # destruction. See Fvwm
    #
    *FvwmThumbnail: GenerateOn raise_window
    *FvwmThumbnail: DeleteOn destroy_window windowshade iconify

One of the reasons for writing this module was to allow miniicons to be redefined
on the fly, and thereby enable the use of a fullscreen pager as a desktop overview screen. To do that, add something like this:

    *FvwmThumbnail: Class BigPager, Factor 0.166666x0.166666
    #
    # Stays on top, cause I don't want screen clutter on top of it
    # WindowSkipList so I can stop it showing itself and blotting 
    # out the rest of that window
    #
    Style FvwmBigPager WindowListSkip, StaysOnTop
    #
    # adjust for local colorsets and screen size
    #
    DestroyModuleConfig FvwmPager: FvwmBigPager
    *FvwmBigPager: Geometry 1280x800+0+0
    *FvwmBigPager: UseSkipList
    *FvwmBigPager: Rows 2
    *FvwmBigPager: Colorset 0 $[cset_wall_0]
    *FvwmBigPager: Colorset 1 $[cset_wall_1]
    *FvwmBigPager: Colorset 2 $[cset_wall_2]
    *FvwmBigPager: Colorset 3 $[cset_wall_3]
    *FvwmBigPager: Font none
    *FvwmBigPager: NoSeparators        # turn off the lines 
    *FvwmBigPager: MiniIcons
    #
    # I got it bound to WindowsKey+Shift+T-for-teleport
    #
    Key T A 4S FuncInvokeBigPager
   
    DestroyFunc FuncInvokeBigPager
    AddToFunc FuncInvokeBigPager
    + I SendToModule FvwmThumbnail Apply BigPager WindowId %w \
 	   WindowStyle EWMHMiniIconOverride, MiniIcon %i
    + I Module FvwmPager -transient FvwmBigPager 0 3
    + I WindowId (FvwmBigPager) Layer 0 10                  # way high 

    Key T A 4 ThisWindow SendToModule FvwmThumbnail Thumbnail $[w.id]
    Key S A 4 SendToModule FvwmThumbnail ScreenShot $[HOME]/screenshot.png
    Key W A 4 SendToModule FvwmThumbnail WinShot $[w.id] $[HOME]/winshot.png

=head1 TODO

Mutliple commands for Apply.

User control over which events are used to generate thumbs


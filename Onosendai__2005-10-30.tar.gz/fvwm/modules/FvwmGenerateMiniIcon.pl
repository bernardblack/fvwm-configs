#!/usr/bin/perl

use lib `fvwm-perllib dir`;
use FVWM::Module;


#-- subs ----------------------------------------------------------------------#

# sigNewPage :: exec'd upon M_NEW_PAGE
# window width : desktop orizontal resolution = pager window width : pager desktop width
# window height : desktop vertical resolution = pager window height : pager desktop height
# pager window window = (window window * pager desktop width) / desktop orizontal resolution
sub sigNewPage {
    my ($module, $event) = @_;

    my $width = $event->_vp_width;
    my $height = $event->_vp_height;
    my $scale_width = ($width * 70) / $psize_x;
    my $scale_height = ($height * 55) / $psize_y;

    #$module->send("WindowStyle EWMHMiniIconOverride, MiniIcon $[fvwm_tmp]/pager/miniicon.tmp.$[w.id].png");
}


#-- main ----------------------------------------------------------------------#

# figure out page size aka screen res
open(XWININFO, "xwininfo -root|") || die "can't run xwininfo";
while ( <XWININFO> ) {
    $psize_x = $1 if /Width:\s*(\d+)/;
    $psize_y = $1 if /Height:\s*(\d+)/;
}
close(XWININFO);

my $module = new FVWM::Module(Mask => M_NEW_PAGE, Debug => 0);
$module->addHandler(M_NEW_PAGE, \&sigNewPage);
$module->eventLoop;


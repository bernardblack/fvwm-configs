#!/usr/bin/ruby
NomMenu = ARGV[0]
def browse_music(nom,nb,type)
	case type
		when 1
			puts "DestroyMenu recreate MenuMPDBrowse#{nb}"
			puts "AddToMenu MenuMPDBrowse#{nb} \"Fichier #{nom[/[^\/]*\Z/]}\" Title"
			puts "AddToMenu MenuMPDBrowse#{nb} \"Ajouter � la playlist\" Exec exec mpc add \"#{nom}\" "
			break
		when 0 
			if nom == "root"
			 puts "DestroyMenu recreate MenuMPDBrowse0"
			 puts "AddToMenu MenuMPDBrowse0 \"Fichiers MPD\" Title"
			 nom = "" 
			else
			 puts "DestroyMenu recreate MenuMPDBrowse#{nb}"
			 puts "AddToMenu MenuMPDBrowse#{nb} \"R�pertoire #{nom[/[^\/]*\Z/]}\" Title"
			end
			puts "AddToMenu MenuMPDBrowse#{nb} \"Ajouter tout � la playlist\" Exec exec mpc add \"#{nom}\" "
			puts "AddToMenu MenuMPDBrowse#{nb} \"Remplacer la playlist\" Piperead 'mpc clear; mpc add \"#{nom}\"' "
			puts "AddToMenu MenuMPDBrowse#{nb} \"\" Nop"
			f=IO.popen("mpc ls \"#{nom}\"")
			i=0
			f.each do |line|
			 i+=1
			 line.chomp!
 			 newnb=nb+"_#{i}"
			 if line[/(.*\.(mp3|ogg|wma|mpc|wav|MP3|OGG|WMA|MPC))/] != nil
			  t=1
                	  puts "AddToMenu MenuMPDBrowse#{nb} \"#{line[/[^\/]*\Z/]}\" Popup MenuMPDBrowse#{newnb}" 
			 else
			  t=0
                	  puts "AddToMenu MenuMPDBrowse#{nb} \"(#{line[/[^\/]*\Z/]})\" Popup MenuMPDBrowse#{newnb}"
			 end
			 puts "DestroyMenu recreate MenuMPDBrowse#{newnb}"
			 puts "AddToMenu MenuMPDBrowse#{newnb} DynamicPopupAction Piperead '#{$0} \\\"#{line}\\\" #{newnb} #{t}'"
			 #browse_music("#{line}",newnb,t)
			end 
			
			
	end
end
#rowse_music("","0",0)
browse_music(ARGV[0],ARGV[1],ARGV[2].to_i)

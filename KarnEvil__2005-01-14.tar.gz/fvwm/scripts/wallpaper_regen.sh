#!/bin/sh
test -d $1/.thumbs || mkdir $1/.thumbs
for t in $1/.thumbs/*.png; do
	base=`basename $t .png`;
	test -f $1/$base || rm -f $t $1/.thumbs/$base.info
done
for w in $1/*; do
	thumbname=$1/.thumbs/`basename $w`.png;
	thumbinfo=$1/.thumbs/`basename $w`.info;
	if [[ `identify -format "%h" $w` -ge 480 &&  `identify -format "%w" $w`  -ge 640 ]]
	then
		test -f $thumbname || convert -scale $2x$2 $w png:$thumbname
		test -f $thumbinfo || identify -format '%wx%h' $w > $thumbinfo 
	fi
done;		

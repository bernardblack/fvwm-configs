#!/usr/bin/ruby
system("echo *");	
wp_program = "Esetroot -scale";
require 'RMagick'
include Magick



class Thumb
	def initialize(path,name,size)
		@path=path;
		@name=name;
		@imagepath=path + ".thumbs/" + ".tmp." + name + ".png"
		@imageinfo=path + ".thumbs/" + ".tmp." + name + ".info"
		if !FileTest.exists?(@imagepath) then
			image=Image.read(path).first
			@width=image.columns
			@height=image.rows
			image.resize!(size,size*0.75).write(imagepath)
			
		else 
	end
	def create_thumb()
		Image.read(path).first.resize!(size,size*0.75).write(imagepath)
	end
	end 
	def write_info()
		infofile=File.open(@imageinfo,"w")
		infofile.print("#{@width}x#{@height}")
		infofile.close
	end
	def read_info()
		infofile=File.open(@imageinfo,"r");
		(width, height) = infofile.readlines[0].scan(/[0-9]+/)
		infofile.close
	end
	def to_s()
		"[#{width}x#{height}] #{nom}";
	end

end

def set_wallpaper(commande, wp, wp_link)
	system(wp_program, wp);
	system("ln -sf", wp_link, wp);
end

set_wallpaper("echo", "Hello", "World");

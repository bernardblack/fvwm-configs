#!/bin/sh
test -f $1/.thumbs || mkdir $1/.thumbs
for w in $1/*; do
        thumbname=$1/.thumbs/`basename $w`.png;
        thumbinfo=$1/.thumbs/`basename $w`.info;
	test -f $thumbname && echo "AddToMenu MenuWallpaper \"[`cat $thumbinfo`] `basename $w`\"%$thumbname% Exec exec \$[fvwm_script_path]/wallpaper_set.sh \"$w\" \$[fvwm_wallpaper_link]";
done


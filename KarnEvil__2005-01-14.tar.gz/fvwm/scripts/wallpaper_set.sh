#!/bin/sh
test -f $1 && Esetroot -scale $1;
ln -sf $1 $2;

#!/usr/bin/ruby
NomMenu = ARGV[0]
f=IO.popen("ps x | grep -v grep | grep -v defunct | grep -v #{$0} | grep -v ps")
print "DestroyMenu recreate #{NomMenu}\n"
print "AddToMenu #{NomMenu} \"Liste des process\" Title\n"
f.readline
f.each do |line|
 a = line.gsub(/\s*(.*)/,'\1').chomp.split(/\s+/)
 pid = a[0]
 if a[1]=='?'
  term = "aucun"
 else
  term = a[1]
 end
 completename = a[4]
 if a[5] != nil
  5.upto(a.size-1) { |i| completename+=" "+a[i] }
 end
 name = completename[/\S+/].gsub(/[A-Za-z0-9_\-\.]+\//,'').delete('/')
 print "AddToMenu #{NomMenu} \"#{pid} - #{name}\" Popup MenuProc#{pid}\n"
 print "DestroyMenu recreate MenuProc#{pid}\n"
 print "AddToMenu MenuProc#{pid} \"Process #{pid}\" Title\n"
 print "AddToMenu MenuProc#{pid} \"Commande: #{completename}\" Nop\n"
 print "AddToMenu MenuProc#{pid} \"PID: #{pid}\" Nop\n"
 print "AddToMenu MenuProc#{pid} \"Terminal: #{term}\" Nop\n"
 print "AddToMenu MenuProc#{pid} \"\" Nop\n"
 print "AddToMenu MenuProc#{pid} \"Terminer #{name}\" Exec exec kill -15 #{pid}\n"
 print "AddToMenu MenuProc#{pid} \"Tuer #{name}\" Exec exec kill -9 #{pid}\n"
 print "AddToMenu MenuProc#{pid} \"Tuer tous les  #{name}\" Exec exec killall #{name}\n"
end

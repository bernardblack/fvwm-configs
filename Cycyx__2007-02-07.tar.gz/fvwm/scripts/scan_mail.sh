#! /bin/bash
#
# Helper script to count mails in my mailbox (in Maildir format)
#

declare MAIL_DIRS=$(find /home/cyriac/Mail -type d -name new)
declare -i count
declare -i total=0
declare -i perso=0
declare -i pro=0

for DIR in $MAIL_DIRS; do
  count=$(ls -1 $DIR | wc -l)
  if [ -n "$(echo $DIR | grep Name)" ]; then
    perso=$count
  fi
  total=$((total + count))
done

pro=$((total-perso))

if [ $total -gt 0 ]; then
  FvwmCommand "MailPopup $pro $perso"
fi

echo $total


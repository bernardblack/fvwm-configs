#! /bin/bash
#
# Helper script for dynamic menu
#

if [ -n "$1" -a -d "${1//�/ }" ]; then
  echo DestroyMenu recreate $1
  echo AddToMenu $1
  echo + DynamicPopDownAction DestroyMenu $1
  echo + MissingSubmenuFunction FileBrowserHelper
  echo + \"%console.png%Terminal\" Exec cd \"${1//�/ }\"\; \$\[fvwm_term\] \$\[fvwm_term_opts\] -T \"Browse: ${1//�/ }\"
  echo + \"%filemngr.png%File Manager\" Exec exec \$\[fvwm_fm\] \"${1//�/ }\"
  echo + \"\" Nop
  if [ "$(echo "${1//�/ }" | grep "^/\+media/[^/]\+$")" ]; then
    echo + \"%drive_go.png%Unmount\" Exec exec pumount \"${1//�/ }\"
    echo + \"\" Nop
  fi

  for file in "${1//�/ }"/*; do
    if [ -d "${file}" ]; then
      if [ -r "${file}" ]; then
        echo + \"%folder.png%$(basename "${file}")\" Popup "${file// /�}" item +100 c
      else
        echo + \"%unrd_folder.png%$(basename "${file}")\"
      fi
    fi
  done
fi


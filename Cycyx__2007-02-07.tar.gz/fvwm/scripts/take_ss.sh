#! /bin/bash
#
# Take a screenshot, copy filename to xclipbord (if xclip is installed),
# show filename and display miniature (if you want...).
# Interactive mode if Xdialog is installed.
#
# Useful for binding to "Print Screen" key.
#

declare SSDIR="${HOME}/Files/Images/ScreenShots"
declare X=1

##### CONFIGURATION OPTIONS #####
# Might be jpg, tiff, tga, bmp, gif, ... See Image Magick for supported formats
declare EXT="png"
##### END OF CONFIGURATION #####

if [ ! -d $SSDIR ]; then
  mkdir -p $SSDIR
fi

if [ ! $(which import) ]; then
  echo "import not found. Please install ImageMagick."
  exit 1
fi

if [ ! $(which Xdialog) ]; then
  echo "Xdialog not found. Please install it. Don't running in interactive mode."
  X=0
fi

declare SSCMD="import -window root"
declare SSNAME="screenshot-$(date +"%Y%m%d%H%M%S").${EXT}"

$SSCMD ${SSDIR}/$SSNAME

if [ $(which xclip) ]; then
  echo -n "${SSDIR}/$SSNAME" | xclip -i
fi

if [ "$X" -eq 1 ]; then
  Xdialog --title "Screenshot taken !" --yesno "See ${SSDIR}/$SSNAME ?" 5 70

  if [ $? -eq 0 ]; then
    display -resize 600 ${SSDIR}/$SSNAME
  fi
fi

exit


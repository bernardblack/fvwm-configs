#! /bin/bash
#
# Helper script launched by ivman to delete removable media icon on desktop
#

##### CONFIGURATION OPTIONS #####
warn_user=1
##### END OF CONFIGURATION #####

device="$1"
label="${2:-Volume}"

info="/dev/shm/icons"

total=$(cat $info | wc -l)
line=$(grep "$device" $info -n -m 1 | cut -d':' -f1)
name=$(cat $info | sed -n -e "${line}p" | awk '{ print $NF }')

if [ $line -lt $total ]; then
  sed -e "${line}c \\\\" -i $info
else
  sed -e "${line}d" -i $info
fi

FvwmCommand "DelIcon $name"

if [ $warn_user ]; then
  xmessage "$label ($device) unmounted"
fi


#! /bin/bash
#
# Helper script launched by ivman to add removable media icon on desktop
#

if [ $# -lt 2 ]; then
  echo "Wrong number of arguments"
  echo "Syntax: $0 device path label"
  exit 1
fi

##### CONFIGURATION OPTIONS #####
horizontal=1
size=20
warn_user=1
v_offset=0 # Vertical offset (no icons along side the top border)
h_offset=0 # Horizontal offset (no icons along side the left border)
##### END OF CONFIGURATION #####

device="$1"
path="$2"
label="$3"

info="/dev/shm/icons"

name="$(basename ${device//[0-9]/})$label${path//\//}"
name=${name//_/}

if [ "$device" == "/dev/mmcblk0p1" ]; then
  icon="sd_card.png"
elif [ -n "$(echo "$device" | grep "/dev/sd")" ] ;then
  icon="usb.png"
elif [ -n "$(echo "$device" | grep "/dev/sr")" -o \
       -n "$(echo "$device" | grep "/dev/cd")" -o \
       -n "$(echo "$device" | grep "/dev/dvd")" ]; then
  icon="cd.png"
else
  icon="drive.png"
fi

touch $info
num_locations=$(cat $info | wc -l)
num_icons=$(cat $info | grep -v ^$ | wc -l)

if [ $num_icons -lt $num_locations ]; then
  spot=$(grep ^$ $info -n -m 1 | cut -d':' -f1)
  sed -e "${spot}c $device $path $label" -i $info
  spot=$((spot-1))
else
  echo $device $path $label $name >> $info
  spot=$num_locations
fi

if [ $horizontal ]; then
  geometry="${size}x${size}+$((spot*size))+${h_offset}"
else
  geometry="${size}x${size}+${v_offset}+$((spot*size))"
fi

FvwmCommand "AddIcon $name $icon $path $geometry"

if [ $warn_user ]; then
  xmessage "$label ($device) mounted on $path"
fi


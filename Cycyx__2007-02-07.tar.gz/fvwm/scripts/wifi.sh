#! /bin/bash
#
# Script getting wifi link quality
#

grep "^  .*0" /proc/net/wireless >/dev/null 2>&1
if [ $? -eq 1 ]; then
  echo "no link"
else
  quality=$(grep "^  .*0" /proc/net/wireless | awk '{ print $3 }')
  quality=${quality/\./}
  echo $quality
fi


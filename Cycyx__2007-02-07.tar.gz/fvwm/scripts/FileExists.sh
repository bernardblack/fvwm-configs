#! /bin/bash
#
# Companion script to test file existence
#

if [ -f "$@" ]; then
        echo true
else
        echo false
fi 

#!/bin/bash
# Note to self:
# Make sure that no output is send to stdout
# only stuff that fvwm can digest is allowed
# Just echo the rest with \# in front of the line

xrandr --verbose | grep mm | awk '{print "+ \""$2 $3 $4"%select.svg:$[icon_size]%\" user_ChangeResolution "$2 $3 $4}' | grep "^+ \"[12345][0-9]\{2\}x" --invert-match 

exit 0

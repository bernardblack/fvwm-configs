if [[ ${height} -ge 600 ]]
then
	echo '$[FVWM_USERDIR]/side_panels.config'
else
	echo Nop
fi
#!/bin/bash

TERMINAL=urxvt
FOREGROUND=grey80
BACKGROUND=black
GEOMETRY="-g 50x1+${small_margin}+${small_margin}"

if [[ $- != *i* ]] ; then
    # shell is non-interactive; display new run box
    urxvt $GEOMETRY --foreground $FOREGROUND --background $BACKGROUND \
    +sb -b 6 -name "run" -title "run" \
    --keysym.C-0xFF0D: "\ ^A $TERMINAL -e \ ^E &\n exit\n" \
    --keysym.0xFF0D: "\ ^A parsecmd \ ^E \n" \
    --keysym.0xFF1B: " &\ ^C exit\n" $@ \
      -e bash --init-file "$0"

else # shell is interactive; we are the run prompt
	export PS1="> "
	HISTCONTROL="ignoreboth"
	HISTFILE=~/.urxvtrun_history
	HISTSIZE=100
	bind '"\t":menu-complete'
fi

function parsecmd {
    if echo -e $@ | grep -e '^ *https\?://' -e '^ *www\.[[:alnum:]]*\.' ; then # handle URL
        [ -z $BROWSER ] && BROWSER=konqueror
        $BROWSER $@ &
    else # run command
        "$@" &
    fi
    echo $@ >> $HISTFILE
    unset HISTFILE
    exit
}


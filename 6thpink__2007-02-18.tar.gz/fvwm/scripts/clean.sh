# Clean links, raw configuration
echo Clean links, for a raw configuration.
rm -f $(find . -type l)

# Clean some temporal crap and backups
echo  Cleaning some temporal crap and backups.
rm -f $(find . -name "*~")
rm -f $(find . -name "magick*")
rm -f .FvwmConsole-History
echo
# Copy all icons
echo Copying all icons...
for i in /usr/share/icons/FlatSVG/scalable/*; do yes | cp ${i}/* icons/menu/; done
# Clean icons, neat and slow stuff :P
# Icons that are not refferenced in the config
# files are wiped out, beware!
echo
echo Clean icons, neat and slow stuff :P         
echo Icons that are not refferenced in the config
echo files are wiped out, beware!
echo =======================
for i in icons/menu/*
do
	if [[ $(grep $(basename ${i}) *) ]]
	then
		echo ${i} IS in your config, keeping.
	else
		echo ${i} IS NOT in your config, cleaning.
		rm -f ${i}
	fi
done

#! /bin/bash

grep "^  .*0" /proc/net/wireless >/dev/null 2>&1
if [ $? -eq 1 ]; then
  echo "no link"
else
  quality=$(grep "^  .*0" /proc/net/wireless | awk '{ print $3 }')
  quality=${quality/./}
  quality=$((quality / 50 + 1))
  echo $quality
fi


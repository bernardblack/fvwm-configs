#! /bin/bash

declare devices_path=/sys/bus/usb/devices
declare devices_org=/dev/shm/usb_devices
declare devices_new=/dev/shm/usb_devices_new
declare usb_num=/dev/shm/usb_devices_num
declare -i num_devices new_devices num_new host_num
declare new device_name

if [ "$1" == "init" ]; then
  /bin/ls -1 $devices_path > $devices_org
  num_devices=$(wc -l $devices_org | awk '{print $1}')
  echo $num_devices > $usb_num
else
  /bin/ls -1 $devices_path > $devices_new
  num_devices=$(cat $usb_num)
  num_new=$(wc -l $devices_new | awk '{print $1}')

  if [ $num_new -gt $num_devices ]; then
    sleep 1
    new=$(diff $devices_org $devices_new | grep ':' | awk '{print $2}')
    host_num=$(/bin/ls -1 ${devices_path}/${new} | grep host | cut -c 5-)
    device_name=$(/bin/ls -1 ${devices_path}/${new}/host${host_num}/target${host_num}:*/${host_num}:*/block/ | grep sd)
    echo "/dev/${device_name}"
  elif [ $num_new -lt $num_devices ]; then
    echo "minus"
  else
    echo "none"
  fi

  mv $devices_new $devices_org
  num_devices=$num_new
  echo $num_devices > $usb_num
fi

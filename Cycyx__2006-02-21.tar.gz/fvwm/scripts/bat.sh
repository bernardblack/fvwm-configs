#! /bin/bash

grep discharging /proc/acpi/battery/BAT0/state >/dev/null 2>&1
if [ $? -eq 1 ]; then
  echo "charging"
  exit
fi

remain=$(grep remaining /proc/acpi/battery/BAT0/state | awk '{ print $3 }')
full=$(grep full /proc/acpi/battery/BAT0/info | awk '{ print $4 }')
echo $((100 * remain / full))


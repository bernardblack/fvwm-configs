#! /bin/bash
#
# Take a screenshot, copy filename to xclipbord (if xclip is installed),
# show filename and display miniature (if you want...).
#
# Useful for binding to "Print Screen" key.
#

SSDIR="${HOME}/Files/Images/ScreenShots"
X=1

if [ ! -d $SSDIR ]; then
  mkdir -p $SSDIR
fi

if [ ! `which import` ]; then
  echo "import not found. Please install ImageMagick."
  exit 1
fi

if [ ! `which Xdialog` ]; then
  echo "Xdialog not found. Please install it. Don't running in interactive mode."
  X=0
fi

SSCMD="import -window root"

SSNAME="screenshot-$(date +"%Y%m%d%H%M%S").png"

$SSCMD ${SSDIR}/$SSNAME

if [ `which xclip` ]; then
  echo -n "${SSDIR}/$SSNAME" | xclip -i
fi

if [ "$X" -eq 1 ]; then
  Xdialog --title "Screenshot taken !" --yesno "See ${SSDIR}/$SSNAME ?" 5 70

  if [ $? -eq 0 ]; then
    display -resize 600 ${SSDIR}/$SSNAME
  fi
fi

exit

#!/bin/sh

scanfile() {
        for i in ${PATHFILE}*.$1 ; do
        FIC=$(basename $i)
        NAMEFIC=${FIC%.*}
        if [ -f ${PATHFILE}${NAMEFIC}.png ]; then
                echo "+ \"%${PATHFILE}${NAMEFIC}.png%${NAMEFIC}\" Exec exec ${MEDIAPLAYER} ${PATHFILE}${NAMEFIC}.$1"
        else
                echo "+ \"${NAMEFIC}\" Exec exec ${MEDIAPLAYER} ${PATHFILE}${NAMEFIC}.$1"
        fi
        done
}

PATHFILE=$1
MEDIAPLAYER=$2

echo 'DestroyMenu recreate "Playlist"'
echo 'AddToMenu "Playlist"'
echo '+ DynamicPopDownAction DestroyMenu "Playlist"'
echo '+ MissingSubmenuFunction FuncFvwmMenuDirectory'

M3U=$(ls ${PATHFILE}*.m3u | wc -l)
PLS=$(ls ${PATHFILE}*.pls | wc -l)
#OGG=$(ls ${PATHFILE}*.ogg | wc -l)
#MP3=$(ls ${PATHFILE}*.mp3 | wc -l)

[ $M3U -gt 0 ] && scanfile m3u
[ $PLS -gt 0 ] && scanfile pls
#[ $OGG -gt 0 ] && scanfile ogg
#[ $MP3 -gt 0 ] && scanfile mp3

exit

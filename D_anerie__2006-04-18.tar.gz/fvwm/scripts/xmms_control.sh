#!/bin/sh

if [ -e /tmp/xmms-info ]; then
    XMMS_INFO=$(cat /tmp/xmms-info)
    XMMS_TITLE=$(echo "$XMMS_INFO" | grep '^Title:' | awk -F: '{print $2}')
else
    XMMS_TITLE="Stopped."
fi

NB_CHAR_TITLE=$(echo $XMMS_TITLE | wc -m)
if [ "$NB_CHAR_TITLE" -gt "80" ] ; then
    XMMS_TITLE=$(echo $XMMS_TITLE | head -c 80)"..."
fi

echo $XMMS_TITLE

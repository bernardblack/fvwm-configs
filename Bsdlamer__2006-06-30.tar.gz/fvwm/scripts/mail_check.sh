#!/bin/sh
mailbox=/var/mail/$LOGNAME
total=`grep 'From: ' $mailbox | wc -l`
if [[ "$total" -ne 0 ]]; then
	echo "You have ${total} mail(s)"
else
	echo "You have no mails"
fi
exit 0

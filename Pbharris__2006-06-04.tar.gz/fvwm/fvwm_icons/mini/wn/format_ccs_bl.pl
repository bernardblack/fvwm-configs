#!/usr/bin/perl -w
use File::Basename;
print "got here 1 \n";

if (($#ARGV == -1)) {
   help_banner();
   exit;
}
readFile($ARGV[0]);

sub readFile {
   my @result;
   my ($front, $addr,$content, $chksum);
   my ($bl_start,$bl_stop);
   $bl_start = "10000000";
   $bl_stop = "1000ef00";
   

   open (LOG, $_[0]) || die "Error:cannot open: $!";
   while ( <LOG> )
   {
     my $line = $_;
     chomp($line);
     $front =substr($line,0,4);
     if ($front eq "S325") {
     $addr = substr($line,4,8);
     $addr0 = hex($addr) + 0;
     $word1 = substr($line,12,8);
     $addr1 = hex($addr) + 4;
     $word2 = substr($line,20,8);
     $addr2 = hex($addr) + 8;
     $word3 = substr($line,28,8); 
     $addr3 = hex($addr) + 12;
     $word4 = substr($line,36,8);
     $addr4 = hex($addr) + 16;
     $word5 = substr($line,44,8);
     $addr5 = hex($addr) + 20;
     $word6 = substr($line,52,8);
     $addr6 = hex($addr) + 24;
     $word7 = substr($line,60,8);
     $addr7 = hex($addr) + 28; 
     $word8 = substr($line,68,8);
#     $b2addr = substr($baddr,6,2); # get last byte of base address
#     print "base address is >>> $b2addr \n"; # print last byte
#     $addr7 = $b2addr + 0x1c; # add last byte of addr7 and 0x1c
#     $a7lb = sprintf( "%02X\n", $addr7);
#     print "$a7lb \n"; # print last byte
#     print "$baddr3\n"; # print last byte


     if (($addr ge  $bl_start) and  ($addr le  $bl_stop) ) {
     print "$addr\n";
     print sprintf("%08X\n",$addr0);
	 print "$word1\n";
     print sprintf("%08X\n",$addr1);
	 print "$word2\n";
     print sprintf("%08X\n",$addr2);
	 print "$word3\n";
     print sprintf("%08X\n",$addr3);
	 print "$word4\n";
     print sprintf("%08X\n",$addr4);
     print "$word5\n";
     print sprintf("%08X\n",$addr5);
     print "$word6\n";
     print sprintf("%08X\n",$addr6);
     print "$word7\n";
     print sprintf("%08X\n",$addr7);
	 print "$word8\n";
	 #print  "$front, $addr, $content, $chksum\n";
	 #print  "$content\n";
	 }
     }
   }
   
   close(LOG);
}

sub help_banner {
   print "usage: input bootloader srec name\n";
   print "       Output To Screen ccs info\n";
   print "          \n";
   exit;
}


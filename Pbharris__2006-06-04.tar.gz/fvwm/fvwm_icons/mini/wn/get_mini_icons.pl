#!/usr/bin/perl -w
use File::Basename;
if (($#ARGV == -1)) {
   help_banner();
   exit;
}
readFile($ARGV[0]);
sub readFile {
   my @result;
   my ($iconfile,$location,$tmpfile);
   open (LIST, $_[0]) || die "Error:cannot open: $!";
   while ( <LIST> )
   {
     my $line = $_;
     chomp($line);
     $iconfile = $line;
     $location = `locate -l 1 $iconfile`;
     chomp($location);
     system("cp $location /home/pbharris/.fvwm/icons/mini/wn/$iconfile");
     print " pbh $location";
   }
   close(LIST);
}
sub help_banner { 
   print "usage: get_mini_icons.pl <list.txt> \n";
   print "          \n";
   exit;
}


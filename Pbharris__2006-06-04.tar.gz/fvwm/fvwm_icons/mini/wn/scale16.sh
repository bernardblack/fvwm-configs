#!/bin/bash
# If there are any xpm files covert to png.
if [ -a "*.xpm" ]; then
   for i in *.xpm
   do
      name=$(echo $i|sed 's/\.xpm$//')
      convert "$name.xpm" "$name.png"
   done
fi

# Scale all png to 16 pixals high.
for i in *.png
do
   name=$(echo $i|sed 's/\.png$//')
   convert -scale 16 "$name.png" "scaled.$name.png"
   rm "$name.png"
   mv "scaled.$name.png" "$name.png"
done


#!/bin/bash

path="/mnt/backup/partage/films/"
cd $path &&
find *ogm *avi -exec echo "+ %24x24/apps/totem.png%\"{}\" Exec exec xine $path\"{}\"" \;
	

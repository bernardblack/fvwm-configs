#!/bin/bash

NOW=`date '+%Y%m%d'`
NAME=fvwm${NOW}
EXT=jpg

cd /home/ryo/docs

scrot -d 5 ${NAME}.${EXT}

feh -g 640x480 ${NAME}.${EXT}

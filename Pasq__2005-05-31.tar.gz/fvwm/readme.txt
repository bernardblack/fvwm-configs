Be careful, some scripts deleting .Xdefaults

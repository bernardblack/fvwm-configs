#!/bin/bash

for pic in `ls $1`; do
	echo "+ %$1/$pic/thumb.png%\"$pic\" RefreshTheme $1 $pic";		
	done



#!/bin/bash
# $1 = nb de pages x
# $2 = nb de pages y
# $3 = page courante x
# $4 = page courante y
for i in $(seq 0 $((${1}-1))); do
  for j in $(seq 0 $((${2}-1))); do
    [[ ${i}${j} != ${3}${4} ]] && echo "+ \"$((${i}+1))x$((${j}+1))\" MoveToPage ${i} ${j}";
  done;
done;

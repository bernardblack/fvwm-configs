#!/bin/sh
cd ~/.fvwm/playlist
rm *
wget -q http://di.fm/mp3/trance96k.pls
wget -q http://di.fm/mp3/hardtrance96k.pls
wget -q http://di.fm/mp3/vocaltrance96k.pls
wget -q http://di.fm/mp3/eurodance96k.pls
wget -q http://di.fm/mp3/goapsy96k.pls
wget -q http://di.fm/mp3/deephouse96k.pls
wget -q http://di.fm/mp3/hardhouse96k.pls
wget -q http://di.fm/mp3/hardcore96k.pls
wget -q http://di.fm/mp3/classictechno96k.pls
wget -q http://di.fm/mp3/chillout96k.pls
wget -q http://di.fm/mp3/djmixes96k.pls
wget -q http://di.fm/mp3/classical96k.pls
wget -q http://di.fm/mp3/newage96k.pls
wget -q http://di.fm/mp3/jazz96k.pls
wget -q http://di.fm/mp3/salsastream96k.pls
wget -q http://www.smoothjazz.com/scast_lo.m3u

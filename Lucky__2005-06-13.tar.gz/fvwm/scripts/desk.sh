#!/bin/bash
echo AddToMenu $1
if [[ $2 -gt 0 ]]; then
        for i in `seq 0 $(($2-1))`; do
            echo + \"Bureau $(($i+1))\" MoveToDesk 0 $i;
        done
fi

if [[ $2 -lt $3 ]]; then
    for i in `seq $(($2+1)) $3`; do
        echo + \"Bureau $(($i+1))\" MoveToDesk 0 $i;
    done
fi


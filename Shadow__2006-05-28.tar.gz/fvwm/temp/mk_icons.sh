#!/bin/bash

cd ./icons

for i in *;
do
  echo "Converting $i"
  convert $i -resize 16x16 16x16/$i;
  convert $i -resize 48x48 48x48/$i;
done


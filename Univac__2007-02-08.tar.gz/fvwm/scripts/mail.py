#!/usr/bin/python
# Simple IMAP count script
# univac <univac@puszkin.org>

import sys
import imaplib
from string import split

try:
    i = imaplib.IMAP4_SSL("puszkin.org")
    i.login("univac", "secret")
except:
    print "Mail: ?"
    sys.exit(1)

i.select("Inbox", readonly=1)
resp, msgs = i.search(None, "(UNSEEN UNDELETED)")
result = split(msgs[0])
print "Mail: %i" % len(result)

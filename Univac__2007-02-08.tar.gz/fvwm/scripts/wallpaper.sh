#!/bin/bash

[ -d $1/.thumbs ] || mkdir $1/.thumbs
for pic in `find $1/* -exec basename {} .png \;`; do
    [ -f $1/.thumbs/$pic.png ] || convert -quality 0 -resize 48 $1/$pic.png $1/.thumbs/$pic.png
    echo "+ %$1/.thumbs/$pic.png%\"$pic\" Exec exec \`ln -sf $1/$pic.png $1/.current && ${fvwm_root} $1/$pic.png\`"
done

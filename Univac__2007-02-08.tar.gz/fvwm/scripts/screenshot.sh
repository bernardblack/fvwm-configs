#!/bin/bash

DATE=`date '+%Y%m%d'`
FNAME=fvwm${DATE}.jpg
DELAY="5"
QUALITY="90"
cd ${HOME}/screenshoty

scrot -d ${DELAY} -q ${QUALITY} ${FNAME}
/usr/bin/FvwmCommand "ScreenshotPopup Screenshot::Taked"
${scripts}/imageshack.py ${FNAME} > ${scripts}/link
#ADRESS=`sed -n 's/.*=\([^]]*\)\].*/\1/p' ${scripts}/link`
ADRESS=$(cat ${scripts}/link |head -n 1)
/usr/bin/firefox $ADRESS
/usr/bin/FvwmCommand "ScreenshotPopup Screenshot::Uploaded"

#!/usr/bin/python
# Last Ebuild display script
# univac <univac@puszkin.org>

import sys
import urllib
from random import choice

try:
    data = urllib.urlopen('http://packages.gentoo.org/archs/x86/testing/gentoo_simple.rss').read()
    datalist = data.splitlines()
except:
    print "Couldn\'t Connect!"
    sys.exit(1)

final = []
for x in datalist:
    # REMOVE WHITESPACES IN THE BEGINNING OF EACH LINE
    line = x.strip()
    if line.startswith('<title>'):
        final.append(line[7:-8])

try:
    result =  choice(final[2:-1])
except:
    print "Couldn\'t Connect!"
    sys.exit(1)

if len(result) > 36:
    print result.split("/")[1]
else:
    print result

#!/usr/bin/perl

use strict;

my $server = {
	1 => {
		SERVER_NAME => 'Puszkin',
        SERVER_ADDRESS => 'puszkin.org',
		USERNAME => 'univac',
		PASSWORD => 'secret',
		MUA => 'thunderbird',
    },
};

print check_mail($server);
exit 0;

sub check_mail {
    my $self = shift;
	use Mail::IMAPTalk;
	my $out;
	my $subMenu;

	foreach my $server (sort {$a<=>$b} keys %$self) {
        my $ServerName = $self->{$server}->{SERVER_NAME};
        my $mua = $self->{$server}->{MUA};
        my $IMAP = Mail::IMAPTalk->new(
            Server   => $self->{$server}->{SERVER_ADDRESS},
            Username => $self->{$server}->{USERNAME},
            Password => $self->{$server}->{PASSWORD},
            Uid      => 1
        ) || die "Failed to connect/login to IMAP server";

        $IMAP->select('INBOX') || die $@;
		my $msgs = $IMAP->search('not','seen');

        $out .= "+ \"$ServerName [";
        $out .= scalar @$msgs;
        $out .= "]\" Popup subMenuServer" . $server;
        #$out .= "\n+ \"\" Nop\n";

        if (scalar @$msgs > 0) {
            $subMenu .= "\nDestroyMenu subMenuServer" . $server;
            $subMenu .= "\nAddToMenu subMenuServer" . $server . " \"$ServerName\" Title\n";
            #$subMenu .= "\n+ \"\" Nop\n";

            foreach my $msg (@$msgs) {
                if ($IMAP->fetch($msg, 'envelope')) {
                    my $MsgEv = $IMAP->fetch($msg, 'envelope')->{$msg}->{'envelope'};
                    $MsgEv->{Date} =~ s/\s\+\d\d\d\d$//;
                    $subMenu .= "+ \"Date: " . shrink($MsgEv->{Date}) . "\" Exec exec $mua";
                    $subMenu .= "\n";
                    $subMenu .= "+ \"From: " . shrink($MsgEv->{From}) . "\" Exec exec $mua";
                    $subMenu .= "\n";
                    $subMenu .= "+ \"To: " . shrink($MsgEv->{To}) . "\" Exec exec $mua";
                    $subMenu .= "\n";
                    $subMenu .= "+ \"Subject: " . shrink($MsgEv->{Subject}) . "\" Exec exec $mua";
                    $subMenu .= "\n";
                    $subMenu .= "+ \"\" Nop\n"
                } else {
                    $subMenu .= "\n";
                }
			}

		}
	}

	$out .= $subMenu;
	return $out;

}

sub shrink {
	my $self = shift;
	$self =~s/"//gmx;
	if (length($self) > 50) {$self = substr($self,0,50) . '...';}
	return $self;
}

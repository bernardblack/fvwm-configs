#include <X11/Xlib.h>
#include <Imlib2.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
        Imlib_Image image, image_out;
	int w, h, wout, hout;

        if ( argc != 5 ) {
       puts("Usage: TargetWidth TargetHeight ImageIn ImageOut");
       return 1;
   }
	sscanf(argv[1], "%d", &wout);
	sscanf(argv[2], "%d", &hout);
	image = imlib_load_image(argv[3]);
	imlib_context_set_image(image);
        w = imlib_image_get_width();
        h = imlib_image_get_height();
	image_out = imlib_create_cropped_scaled_image(0, 0, w, h, wout, hout);
	imlib_context_set_image(image_out);
        imlib_save_image(argv[4]);
	return 0;
}

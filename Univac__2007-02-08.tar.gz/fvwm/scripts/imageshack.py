#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

# script to upload images to imageshack
# ld <dot> fifty <dot> gmail <dot> com
# ld-50 @ freenode; lethal @ ptnet

VERSION = 1.0

import httplib, mimetypes, urlparse, sys, string, sgmllib

FORM_ACTION = "http://www.imageshack.us/index.php"
EXTENSIONS = ['pg', 'jpeg', 'png', 'gif', 'bmp', 'tif', 'tiff', 'swf', 'jpg']

# em bytes
MAX_FILE_SIZE="1572864"
#--------------------------------------------------------------------------
class MyParser(sgmllib.SGMLParser):
    "A simple parser class."

    def parse(self, s):
        "Parse the given string 's'."
        self.feed(s)
        self.close()

    def __init__(self, verbose=0):
        "Initialise an object, passing 'verbose' to the superclass."

        sgmllib.SGMLParser.__init__(self, verbose)
        self.hyperlinks = []

    def start_input(self, attributes):
        "Process a hyperlink and its 'attributes'."

        for name, value in attributes:		
		if name == "value":
			self.hyperlinks.append(value)

    def get_hyperlinks(self):
        "Return the list of hyperlinks."
        return self.hyperlinks
#--------------------------------------------------------------------------
def posturl(url, fields, files):
    urlparts = urlparse.urlsplit(url)
    return post_multipart(urlparts[1], urlparts[2], fields, files)

#--------------------------------------------------------------------------
def post_multipart(host, selector, fields, files):
    """
    Post fields and files to an http host as multipart/form-data.
    fields is a sequence of (name, value) elements for regular form fields.
    files is a sequence of (name, filename, value) elements for data to be uploaded as files
    Return the server's response page.
    """
    content_type, body = encode_multipart_formdata(fields, files)
    h = httplib.HTTP(host)
    h.putrequest('POST', selector)
    h.putheader('content-type', content_type)
    h.putheader('content-length', str(len(body)))
    h.endheaders()
    h.send(body)
    errcode, errmsg, headers = h.getreply()
    return h.file.read()
#--------------------------------------------------------------------------
def encode_multipart_formdata(fields, files):
    """
    fields is a sequence of (name, value) elements for regular form fields.
    files is a sequence of (name, filename, value) elements for data to be uploaded as files
    Return (content_type, body) ready for httplib.HTTP instance
    """
    BOUNDARY = '----------ThIs_Is_tHe_bouNdaRY_$'
    CRLF = '\r\n'
    L = []
    for (key, value) in fields:
        L.append('--' + BOUNDARY)
        L.append('Content-Disposition: form-data; name="%s"' % key)
        L.append('')
        L.append(value)
    for (key, filename, value) in files:
        L.append('--' + BOUNDARY)
        L.append('Content-Disposition: form-data; name="%s"; filename="%s"' % (key, filename))
        L.append('Content-Type: %s' % get_content_type(filename))
        L.append('')
        L.append(value)
    L.append('--' + BOUNDARY + '--')
    L.append('')
    body = CRLF.join(L)
    content_type = 'multipart/form-data; boundary=%s' % BOUNDARY
    return content_type, body
#--------------------------------------------------------------------------
def get_content_type(filename):
    return mimetypes.guess_type(filename)[0] or 'application/octet-stream'
#--------------------------------------------------------------------------
def main():
	if len(sys.argv) != 2:
		print "usage: imageshack filename\n"
		sys.exit(1)
		
	filename = sys.argv[1]
	extension = filename.split(".")[-1]
	
	if ('.' not in filename or extension.lower() not in EXTENSIONS):
		print "Only the following extensions are allowed: " + string.join(EXTENSIONS) + "\n"
		sys.exit(1)
		
	try:
		f = open(filename, 'r')
		conteudo = f.read()
		f.close()
	except IOError, (errno, strerror):
		print "%s:" % (strerror)
		sys.exit(1)

	ret_val = posturl(FORM_ACTION, [('MAX_FILE_SIZE', '3145728'), ('uploadtype', 'on'), ('optimage', '1'), ('resizeoptions', ''), ('rembar', '1')], [('fileupload', 'filename', conteudo)])
	
	myparser = MyParser()
	myparser.parse(ret_val)

	links = myparser.get_hyperlinks()
	links = filter(lambda x: x.startswith('http'), links)
	
	if len(links) > 1:
		print links[1]
		print
		sys.exit(0)
	else:
		print 'Error uploading image'
		sys.exit(1)
#--------------------------------------------------------------------------
main()
#!/bin/bash

process=""
process=$(ps -A | sed 's/^........................//' | grep esperanza | head -n 1)
#process=$(ps -A | grep gxmms2 | cut -d ' ' -f 8 | nl -n ln | grep 1 | cut -f 2)

if [ "$process" = "esperanza" ]
	then
		killall esperanza
		esperanza &
	else
		esperanza &
fi

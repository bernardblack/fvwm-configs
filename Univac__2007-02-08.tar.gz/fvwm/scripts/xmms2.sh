#!/bin/bash

if [ -d "$@" ]; then
    xmms2 radd "$@"
else
    xmms2 add "$@"
fi

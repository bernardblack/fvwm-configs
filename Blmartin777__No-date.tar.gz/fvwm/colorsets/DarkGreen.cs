# DarkGreen colorset
# Written by: Axquan <axquan@arx.pl>

SetEnv Colorset-Name "DarkGreen"
SetEnv Colorset-Author "Axquan <axquan@arx.pl>"

# What colorsets do we use?
Read $./colorsets

# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# QuakeConsole, thumbnailed windows
Colorset $[cs-quakeconsole] \
Foreground "black", Background "black", \
Hilight "black", Shadow "black", \
IconAlpha 50


Colorset $[cs-panel-inactive] \
Foreground "white", Background "#444444", \
Tint "darkgreen" 50, RootTransparent, \
fgTint "black" 20, IconAlpha 60, IconTint "black" 20

Colorset $[cs-panel-inactive-MiniIcon] \
Foreground "white", Background "#444444", \
Tint "darkgreen" 50, RootTransparent, \
fgTint, IconAlpha, IconTint

Colorset $[cs-panel-active] \
Foreground "darkgray", Background "darkgray", \
Hilight "darkgray", Shadow "darkgray", \
Tint "#1b64a3" 50, RootTransparent

Colorset $[cs-panel-wininactive] \
Foreground "white", Background "gray", \
Hilight "gray", Shadow "gray", \
Tint "#56c847" 20, RootTransparent

Colorset $[cs-panel-winactive] \
Foreground "white", Background "gray", \
Hilight "gray", Shadow "gray", \
Tint "blue" 50, RootTransparent

Colorset $[cs-panel-border] \
Background "gray"

Colorset $[cs-menu-inactive] \
Foreground "white", Background "gray", \
Hilight "gray", Shadow "gray", \
Tint "darkgreen" 50, RootTransparent

Colorset $[cs-menu-active] \
Foreground "white", Background "#1b64a3", \
Hilight "white", Shadow "gray"


# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Additional variables
SetEnv ThumbBorderColor "gray"
SetEnv ExternalFontColor "gray40"

SetEnv TrayerTint "0x006400"
SetEnv TrayerAlpha "128"


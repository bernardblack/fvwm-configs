# CIOS colorset
# Written by: fromooze <fromooze@yahoo.es>

SetEnv Colorset-Name "CIOS"
SetEnv Colorset-Author "fromooze <fromooze@yahoo.es>"

# What colorsets do we use?
Read $./colorsets

# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# QuakeConsole, thumbnailed windows
Colorset $[cs-quakeconsole] \
Foreground "black", Background "black", \
Hilight "black", Shadow "black", \
IconAlpha 50


Colorset $[cs-panel-inactive] \
Foreground "#00ffff", Background "#444444", \
Tint "#00008b" 0, RootTransparent, \
fgTint, fgAlpha 50, IconAlpha 50, IconTint "#00ffff" 50

Colorset $[cs-panel-inactive-MiniIcon] \
Foreground "#00ffff", Background "#444444", \
Tint "#00008b" 0, RootTransparent, \
fgTint, IconAlpha, IconTint

Colorset $[cs-panel-active] \
Foreground "#00ffff", Background "darkgray", \
Hilight "darkgray", Shadow "darkgray", \
Tint "#00ffff" 30, RootTransparent

Colorset $[cs-panel-wininactive] \
Foreground "#00ffff", Background "#00ffff", \
Hilight "#ee92ee", Shadow "#ee82ee", \
Tint "#00008b" 30, RootTransparent

Colorset $[cs-panel-winactive] \
Foreground "#00008b", Background "#00008b", \
Hilight "#00008b", Shadow "#00008b", \
Tint "#00ffff" 50, RootTransparent

Colorset $[cs-panel-border] \
Background "#00ffff"

Colorset $[cs-menu-inactive] \
Foreground "#00ffff", Background "#00ffff", \
Hilight "#00ffff", Shadow "#00ffff", \
Tint "#00008b" 30, RootTransparent

Colorset $[cs-menu-active] \
Foreground "#ee82ee", Background "#00008b", \
Hilight "#00ffff", Shadow "#00ffff"


# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Additional variables
SetEnv ThumbBorderColor "blue"
SetEnv ExternalFontColor "gray40"

SetEnv TrayerTint "0x00008b"
SetEnv TrayerAlpha "256"


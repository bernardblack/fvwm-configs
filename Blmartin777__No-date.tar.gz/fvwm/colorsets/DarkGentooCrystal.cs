# DarkDesktop colorset
# Written by: mart381

SetEnv Colorset-Name "DarkGentooCrystal"
SetEnv Colorset-Author "Brandon C Martin <mart381@comcast.net>"

# What colorsets do we use?
Read $./colorsets

# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# QuakeConsole, thumbnailed windows
Colorset $[cs-quakeconsole] \
Foreground "black", Background "#333333", \
Hilight "#777777", Shadow "#333333", \
IconAlpha 70


Colorset $[cs-panel-inactive] \
Foreground "#888888", Background "#333333", \
Tint "black" 50, RootTransparent, \
fgTint "black" 20, IconAlpha 50, IconTint "black" 20

Colorset $[cs-panel-inactive-MiniIcon] \
Foreground "#888888", Background "#333333", \
Tint "black" 50, RootTransparent, IconAlpha 50, \

Colorset $[cs-panel-active] \
Foreground "#999999", Background "#333333", \
Hilight "#333333", Shadow "#333333", \
Tint "white" 30, RootTransparent

Colorset $[cs-panel-wininactive] \
Foreground "#888888", Background "#333333", \
Hilight "#333333", Shadow "#333333", \
Tint "#999999" 30, RootTransparent, IconAlpha 50, \

Colorset $[cs-panel-winactive] \
Foreground "#777777", Background "#333333", \
Hilight "#333333", Shadow "#333333", \
Tint "black" 5, RootTransparent

Colorset $[cs-panel-border] \
Background "#333333"

Colorset $[cs-menu-inactive] \
Foreground "#888888", Background "#333333", \
Hilight "#333333", Shadow "#333333", \
Tint "black" 70, RootTransparent

Colorset $[cs-menu-active] \
Foreground "black", Background "#888888", \
Hilight "black", Shadow "#888888"


# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Additional variables
SetEnv ThumbBorderColor "gray"
SetEnv ExternalFontColor "gray40"


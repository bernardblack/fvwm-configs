# WhiteDesktop colorset
# Written by: Social

SetEnv Colorset-Name "WhiteDesktop"
SetEnv Colorset-Author "Social"

# What colorsets do we use?
Read $./colorsets

# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# QuakeConsole, thumbnailed windows
Colorset $[cs-quakeconsole] \
Foreground "black", Background "black", \
Hilight "black", Shadow "black", \
IconAlpha 70


Colorset $[cs-panel-inactive] \
Foreground "black", Background "#444444", \
Tint "#aaaaaa" 50, RootTransparent, \
fgTint, IconAlpha 60, IconTint "black" 100

Colorset $[cs-panel-inactive-MiniIcon] \
Foreground "black", Background "#444444", \
Tint "#aaaaaa" 50, RootTransparent, \
fgTint, IconAlpha, IconTint

Colorset $[cs-panel-active] \
Foreground "darkgray", Background "darkgray", \
Hilight "darkgray", Shadow "darkgray", \
Tint "#888888" 50, RootTransparent

Colorset $[cs-panel-wininactive] \
Foreground "#555555", Background "#777777", \
Hilight "#444444", Shadow "#444444", \
Tint "#aaaaaa" 60, RootTransparent

Colorset $[cs-panel-winactive] \
Foreground "black", Background "#777777", \
Hilight "#666666", Shadow "#666666", \
Tint "#aaaaaa" 80, RootTransparent

Colorset $[cs-panel-border] \
Background "#777777"

Colorset $[cs-menu-inactive] \
Foreground "black", Background "white", \
Hilight "white", Shadow "white", \
Tint "#aaaaaa" 50, RootTransparent

Colorset $[cs-menu-active] \
Foreground "#333333", Background "white", \
Hilight "#333333", Shadow "gray"


# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Additional variables
SetEnv ThumbBorderColor "black"
SetEnv ExternalFontColor "gray40"

SetEnv TrayerTint "0xaaaaaa"
SetEnv TrayerAlpha "128"


#!/bin/bash

process=""
process=$(ps -A | grep xmms | cut -d ' ' -f 8 | nl -n ln | grep 1 | cut -f 2)

if [ "$process" = "xmms" ]
	then
		xmms-shell -e 'xmmsexit'
	else
		xmms &
		sleep 2
		xmms-shell -e 'window all hide'
fi

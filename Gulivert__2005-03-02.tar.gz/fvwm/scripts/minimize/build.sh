#!/bin/sh
###################################################################
### Thumbnail in Engage (E17 part)
### By KarnEvil and cptmorgan
### http://forums.gentoo.org/viewtopic.php?t=292447
### http://forums.gentoo.org/viewtopic.php?p=2084007#2084007
###################################################################


cd ~/theme-fvwm/scripts/minimize

xwd -silent -id $1 > .temp.xwd

resolution=`identify .temp.xwd | cut -d" " -f 3`
width=`echo $resolution | cut -dx -f1`
height=`echo $resolution | cut -dx -f2`
if [[ $height -lt $width ]]; then
        convert -resize 194x -frame 1x1 -mattecolor black -quality 0 xwd:.temp.xwd png:.temp.png
        composite -geometry +0+$(((196-($height*196/$width))/2)) .temp.png transparent.png icon.png
else
        convert -resize 196 -frame 1x1 -mattecolor black -quality 0 xwd:.temp.xwd png:icon.png
fi

edje_cc -id . -fd . icon.edc icon.eapp

enlightenment_eapp \
icon.eapp \
-set-name "$2" \
-set-generic "$1" \
-set-comment "$1" \
-set-exe "FvwmCommand \"WindowId $1 DeThumbnail\"" \
-set-win-name "$1" \
-set-win-class "$1" \
-set-wait-exit "1" \

cp -f icon.eapp ~/.e/apps/engage/launcher/$1.eapp

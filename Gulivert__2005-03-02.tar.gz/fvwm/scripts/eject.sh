#!/bin/bash

sudo eject

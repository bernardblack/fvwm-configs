#!/bin/bash
#import -window root ${FNAME}.${EXT}

NOW=`date '+%Y%m%d'`
FNAME=fvwm${NOW}
EXT=png

cd /home/blue/

sleep 5

xwd -root > ${FNAME}.${EXT}

convert -resize 400x300 ${FNAME}.${EXT} fvwm${NOW}_thumb.${EXT}




#!/bin/bash
xmodmap -e "pointer = 1 2 3 11 12 6 7 8 9 10 4 5"


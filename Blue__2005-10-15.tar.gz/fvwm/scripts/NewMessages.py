#!/usr/bin/env python
import libgmail
import sys

if __name__ == "__main__":
   ga = libgmail.GmailAccount(sys.argv[1] + "@gmail.com", sys.argv[2])
   ga.login()
   print ga.getUnreadMsgCount()

if [ -f "$@" ]; then
        echo true
else
        echo false
fi 

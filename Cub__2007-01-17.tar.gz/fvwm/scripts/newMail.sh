#!/bin/bash


FVWM=`ps -ef|grep '[f]vwm'|tr " " "_"`

# make sure we are running fvwm
if [ -z "$FVWM" ]
then
	exit 0
fi

tmp_mail=/tmp/tmp_mail

cat > $tmp_mail

to=`grep -v "\-To" < $tmp_mail |grep -m 1 "To:"|tr " " "_"`
subject=`grep -m 1 "Subject:" < $tmp_mail |tr " " "_"`
from=`grep -m 1 "From:" < $tmp_mail |tr " " "_"`


rm $tmp_mail

fvwmfunction='MailPopup'\ "$from"\ "$subject"\ "$to"

echo "$fvwmfunction"|FvwmCommand -c

#!/bin/bash

mailbox=/home/cub/.maildir/inbox_`date +%Y` 

new=`ls $mailbox/new/|wc -l` 

echo "$new"

#!/bin/bash

fvwm-root -r --dither $1
echo $1 > ~/.fvwm/images/last_wallpaper
FvwmCommand Refresh

#!/usr/bin/perl -w 

use strict; 
use MIME::Parser; 


# tests if fvwm s running 
my $test=`ps ax|grep -c [f]vwm`; 

if ($test==0) { 
exit 0; 
} 

# tests if the screen saver is activated or not 
# nb: requires another perl script to run in the background (xscreensaver.pl) 
my $test2=`ls ~/.fvwm/scripts/|grep -c xscreen_active`; 

if ($test2!=0) { 
exit 0; 
} 

my $FvwmCommand = "FvwmCommand"; 
my $FvwmFunction = "MailPopup"; 
my $maxlength = 60; 

sub prep_string { 
        my $s = shift; 
        chomp $s; 
        $s = substr($s, 0, $maxlength - 1); 
        $s =~ s/\\/\\\\\\\\/g; 
        $s =~ s/\"/\\\\\\\"/g; 
        $s =~ s/\$/\$\$/g; 
        return $s; 
} 

my $parser = new MIME::Parser; 

$parser->ignore_errors(1); 
$parser->output_to_core(1); 
$parser->decode_headers(1); 

my $entity = eval { $parser->parse(\*STDIN) }; 
my $error = ($@ || $parser->last_error); 

my $head = $entity->head; 

my $subject = prep_string($head->get('Subject:')); 
my $from = prep_string($head->get('From:')); 
my $to = prep_string($head->get('To:')); 

my $command = "$FvwmFunction \"$from\" \"$subject\" \"$to\""; 

open(FD, "|$FvwmCommand -c"); 
print FD $command; 
close(FD);

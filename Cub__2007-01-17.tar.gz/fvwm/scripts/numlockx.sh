#!/bin/bash
numlockx on

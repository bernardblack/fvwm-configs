#!/bin/bash

NOW=`date '+%Y%m%d'`
FNAME=fvwm-${NOW}
EXT=png

cd /home/cub/

sleep 5

import -window root ${FNAME}.${EXT}





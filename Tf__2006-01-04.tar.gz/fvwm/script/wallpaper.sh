#!/bin/bash
[ -d $1/.thumbs ] || mkdir $1/.thumbs

ls -1 $1 > $1/.thumbs/pic.tmp
cut -d"." -f2 $1/.thumbs/pic.tmp > $1/.thumbs/suffix.tmp
picfiles=`cat $1/.thumbs/pic.tmp`

for pic in $picfiles
do
  suffix=`echo $pic | cut -f2 -d"."`
  basename_pic=`basename $pic .$suffix`
  [ -f $1/.thumbs/$basename_pic.png ] || convert -quality 0 -resize 48 $1/$basename_pic.$suffix $1/.thumbs/$basename_pic.png
  echo "+ %$1/.thumbs/$basename_pic.png%\"$basename_pic\" exec exec \`ln -sf $1/$basename_pic.$suffix $1/.current && Esetroot -scale $1/$basename_pic.$suffix\`"
  rm -f $1/.thumbs/pic.tmp
  rm -f $1/.thumbs/suffix.tmp
done

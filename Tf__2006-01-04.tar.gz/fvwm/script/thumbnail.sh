#!/bin/sh

# Screenshot nehmen und im RAM ablegen (/tmp sollte ramfs sein)
# $1 ist die ID des Fensters

xwd -silent -id $1 > /dev/shm/icon.tmp.$1.png.xwd


# Fenster dahin schieben, wo es niemand sieht

FvwmCommand "WindowId $1 MoveToDesk 0 6"


# Zu fvwm zur�ckkehren und im Hintergrund nacheinander folgendes ausf�hren:
# - Screenshot aus RAM lesen und ...
# - ... mit convert verkleinern
# - fvwm mitteilen, welches Icon zu dem Fenster geh�rt
# - fvwm befehlen, das Fenster zu minimieren (wegen StickyAcrossDesk-Icons kein verschieben notwendig)
# - von "xwd" erzeigtes Image loeschen

cat /dev/shm/icon.tmp.$1.png.xwd | \
convert -scale 128x128 -quality 0 xwd:- png:/dev/shm/icon.tmp.$1.png
composite -geometry +5+5 $2 /dev/shm/icon.tmp.$[w.id].png /dev/shm/icon.tmp.$[w.id].png && \
FvwmCommand "WindowId $1 WindowStyle IconOverride, Icon /dev/shm/icon.tmp.$1.png || echo Nop" && \
FvwmCommand "WindowId $1 Iconify" && \
rm /dev/shm/icon.tmp.$1.png.xwd &
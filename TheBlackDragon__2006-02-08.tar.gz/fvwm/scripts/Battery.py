#!/usr/bin/env python
import os
import sys

def getPercentage():
    fin = os.popen("/usr/bin/acpi")
    acpi = fin.readline()
    acpi = acpi.split(',')[1].lstrip()
    print acpi

def getTimeRemaining():
    fin = os.popen("/usr/bin/acpi")
    acpi = fin.readline()
    acpi = acpi.split(',')[2].split(" ")[1].rstrip(" ").rstrip('\n')
    print acpi

def isDischarging():
    fin = os.popen("/usr/bin/acpi")
    acpi = fin.readline()
    acpi = acpi.split(',')[0].lstrip(" ").split(" ")[2]
    if acpi == "discharging":
        print "1"
    else:
        print "0"

if __name__ == "__main__":
    if(len(sys.argv) == 1):
        sys.exit(1)
    elif(sys.argv[1] == 'd'):
        isDischarging()
    elif(sys.argv[1] == 'p'):
        getPercentage()
    elif(sys.argv[1] == 't'):
        getTimeRemaining()

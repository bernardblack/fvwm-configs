#!/bin/env python
###############################################################################
# The general invocation form is GenerateMenus.py {m,p} <menuName>            #
# Where m stands for menus, the script will then output normal Fvwm menu      #
#         definitions.                                                        #
#       p stands for Panel, the script will then generate FvwmButtons and     #
#         Panel definitions, that you can use in some kind of menubar         #
# Reads menu entries from menu files, which are flat text files with the      #
# following structure:                                                        #
#  <appName>::<appExecutable>::<appIcon>                                      #
# where appName is free to choose                                             #
#       appExecutable is the name of the applications executable, with        #
#          eventual arguments                                                 #
#       appIcon is path and name of the icon to be used, this should be       #
#          relative to the ImagePath variable if the latter one has been      # 
#          defined                                                            #
# This script expects to find your menu files in the  menu' directory in your #
# FVWM_USERDIR, this is ~/.fvwm on most systems, this directory should        #
# contain all your *.menu files.                                              #
#                                                                             #
# And last, but not least, you should put the following function in your      #
# config when you want to use this script to generate menus, using            #
# the menu's MissingSubMenuFunction:                                          #
#                                                                             #
#   AddToFunc MakeMissingMenu                                                 #
#    + I PipeRead "$[FVWM_USERDIR]/scripts/GenerateMenus.py m $0"             #
#                                                                             #
# When you are generating buttons you should add a button configuration like  #
# the following to your Fvwm config:                                          #
#                                                                             #
# *TopBar: (2x1, Title 'TestMenu', Panel(down, indicator, position button top)#
#  testMenu "Module FvwmButtons testMenu")                                    #
#                                                                             #
# You should then also add a function like the following:                     #
#                                                                             #
# DestroyModuleConfig testMenu: *                                             #
# PipeRead "$[FVWM_USERDIR]/scripts/GenerateMenus.py p testMenu"              #
#                                                                             #
# Copyright (c) Bert 'theBlackDragon' Geens <bert@noSPAM.lair.be              #
# You are free to modify this script in any way you like, even though I would #
# like to be notified of any changes or improvemets you make.                 #
###############################################################################

###############################################################################
# Edit these to your liking, all options supported by FvwmButtons can be used.#
# WARNING: You should leave the Columns option in place otherwise FvwmButtons #
#          WILL crash. You can change it though to anything bigger than 0.    #
###############################################################################
imagepath='/home/theBlackDragon/.fvwm/images/icons/umicons'
panelsettings={'Columns':'1',
	       'Colorset':'2',
	       'ActiveColorset':'3'}

###############################################################################
# Normally you shouldn't need to edit what follows                            #
###############################################################################
import os
import sys

def generateMenu(menuName):
    print 'DestroyMenu ' + menuName
    print 'AddToMenu ' + menuName
    print ' + MissingSubMenuFunction MakeMissingMenu'

    try:
    	file = open( os.path.join(os.environ['FVWM_USERDIR'], 'menus', menuName) + '.menu' ,'r')
    except IOError:
    	print ' + "No such file "' + os.path.join(os.environ['FVWM_USERDIR'], 'menus', menuName) + '".menu Nop'
    	sys.exit(1)

    data = file.readline()
    while(data):
	#process stuff
	values = data.split('::')
	if(values[0]=='Nop'):
	    print ' + "" Nop'
	elif(values[1]==''):
	    #we check if an icon is set, we get rid of the last character as in most cases this will be a newline
	    if(values[2][:-1]):
		#we got an icon, now strip off the eventual newline as otherwise things get messed up
		print ' + %' + os.path.join(imagepath,values[2].strip('\n')) + '%"' + values[0] + '" Popup ' + values[0]
	    else:
		print ' + "' + values[0] + '" Popup ' + values[0]
	else:
	    #we check if an icon is set, we get rid of the last character as in most cases this will be a newline
	    if(values[2][:-1]):
		#we got an icon, now strip off the eventual newline as otherwise things get messed up
		print 'Test (x '+ values[1].split()[0] +') + %' + os.path.join(imagepath,values[2].strip('\n')) + '%"' + values[0] + '" Exec exec ' + values[1]
	    else:
		print 'Test (x '+ values[1].split()[0] +') + "' + values[0] + '" Exec exec ' + values[1]

	#read next line from file
	data = file.readline()

    file.close()

def generatePanel(menuName):
    print 'DestroyModuleConfig ' + menuName + ': *'
    #print '*'+ menuName +': ButtonGeometry 64x40'
    for setting in panelsettings.keys():
	print '*' + menuName + ': ' + setting + ' ' + panelsettings[setting]
    try:
    	file = open( os.path.join(os.environ['FVWM_USERDIR'], 'menus', menuName) + '.menu' ,'r')
    except IOError:
    	 print '*' + menuName + ': (Title "No such file ' + os.path.join(os.environ['FVWM_USERDIR'], 'menus', menuName) + '.menu", action (Mouse 1) Nop)'
	 sys.exit(1)

    data = file.readline()
    menus=[]
    while(data):
	#process stuff
	values = data.split('::')

	#check if it's a spacer, submenu or a regular menu item
	if(values[0]=='Nop'):
	    pass
	elif(values[1]==''):
	    #it's a subpanel
	    menus.append(values[0])
	    #we check if an icon is set, we get rid of the last character as in most cases this will be a newline
	    if(values[2][:-1]):
		#we got an icon, now strip off the eventual newline as otherwise things get messed up
		print '*' + menuName + ': (Icon "' + os.path.join(imagepath,values[2].strip('\n')) + ', Panel(right, indicator 3, position button top) ' + values[0] + ' "Module FvwmButtons ' + values[0] + '")'
	    else:
		print '*' + menuName + ': (Title "' + values[0] + '", Panel(right, indicator 3, position button top) ' + values[0] + ' "Module FvwmButtons ' + values[0] + '")'
	else:
	    #it's a button
	    #we check if an icon is set, we get rid of the last character as in most cases this will be a newline
	    if(values[2][:-1]):
		#we got an icon, now strip off the eventual newline as otherwise things get messed up
		#=>uncomment this and comment the next line if you don't want to see the text below the icons, the text will still be shown for buttons that have no icon though
		#print 'Test (x '+values[1]+' ) *' + menuName + ': (1x1+0+' + str(row) + ', Icon ' + os.path.join(imagePath,values[2].strip('\n')) + ', action (Mouse 1) `Exec exec ' + values[1] + '`)'
		print 'Test (x ' + values[1].split()[0] + ') *' + menuName + ': (Title "' + values[0] + '" , Icon ' + os.path.join(imagepath,values[2].strip('\n')) + ', action (Mouse 1) `Exec exec ' + values[1] + '`)'
	    else:
		print 'Test (x ' + values[1].split()[0 ]+ ') *' + menuName + ': (Title "' + values[0]  + '", action (Mouse 1) `Exec exec ' + values[1] + '`)'

	#read next line
	data = file.readline()

    print 'Style ' + menuName + ' NoTitle, !Borders, WindowListSkip, Sticky'

    for menu in menus:
	print 'DestroyModuleConfig ' + menu
	print 'PipeRead "$[FVWM_USERDIR]/scripts/GenerateMenus.py p ' + menu + '"'
	print 

    file.close()

if __name__ == "__main__":
    if(sys.argv[1] == 'm'):
	generateMenu(sys.argv[2])
    elif(sys.argv[1] == 'p'):
	generatePanel(sys.argv[2])
	

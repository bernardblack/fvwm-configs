#!/usr/bin/perl -Tw
#==========================================================================
#
#         FILE:  calendario.pl
#
#        USAGE:  ./calendario.pl 
#
#  DESCRIPTION:  A small calendar for Fvwm
#
#       AUTHOR:  Miguel Santinho (), <msantinho@simplicidade.com>
#      COMPANY:  Simplicidade.com
#      VERSION:  1.0
#      CREATED:  03-09-2005 15:37:08 WEST
#     REVISION:  ---
#==========================================================================
#==========================================================================
#  This program is free software; you can redistribute it and/or modify 
#  it under the terms of the GNU General Public License as published by 
#  the Free Software Foundation; either version 2 of the License, or    
#  (at your option) any later version.                                  
#==========================================================================

use strict;
use Calendar::Simple;

my $months = {
	1  => 'Januar',
	2  => 'Februar',
	3  => 'M�rz',
	4  => 'April',
	5  => 'Mai',
	6  => 'Juni',
	7  => 'Juli',
	8  => 'August',
	9  => 'September',
	10 => 'Oktober',
	11 => 'November',
	12 => 'Dezember',
};

my $mon = ((localtime)[4] + 1);
my $yr = ((localtime)[5] + 1900);

my @month = calendar($mon, $yr, 1);

# TITULO
print $months->{$mon}, " ", $yr, "\n";

# DIAS SEMANA
print "MO: DI: MI: DO: FR: SA: SO:\n";

foreach my $line (@month) {

	foreach my $dia (@$line) {

		my $dia_out = $dia;

		# MARCAR DIA ACTUAL
		$dia_out = "*" . $dia if $dia
		&& 
		$dia == (localtime)[3]
		&& 
		$mon == ((localtime)[4] + 1);

		if ( $dia_out ) {

			if ( length $dia_out == 1 )
			{
				print "  " . $dia_out . " ";
				
			} elsif ( length $dia_out == 2 )
			{
				print " " . $dia_out . " ";
				
			} elsif ( length $dia_out == 3 )
			{
				print $dia_out . " ";
			}

		} else {
			print "    ";
		}
	}
	print "\n";
}


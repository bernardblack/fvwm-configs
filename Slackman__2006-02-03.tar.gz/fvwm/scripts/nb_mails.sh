#!/bin/bash

mailbox=/home/slackman/mail/new

total=`grep -v ">From" < $mailbox | grep -v ":From" | grep -c "From:"`
status=`grep -v "\-Status" < $mailbox | grep -c "Status:"`

new=$(($total-$status))

echo "$new/$total"

#include <X11/Xlib.h>
#include <Imlib2.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
        Imlib_Image image, image_out, image_tint;
	int w, h, wout, hout, tint;

        if ( argc != 6 ) {
       puts("Usage: test WallpaperFile ScreenWidth ScreenHeight AlphaTint OutputFile");
       return 1;
   }
	sscanf(argv[2], "%d", &wout);
	sscanf(argv[3], "%d", &hout);
	sscanf(argv[4], "%d", &tint);
	image = imlib_load_image(argv[1]);
	imlib_context_set_image(image);
	w = imlib_image_get_width();
	h = imlib_image_get_height();
	image_out = imlib_create_cropped_scaled_image(0, 0, w, h, wout, hout);
	image_tint = imlib_create_image(wout, hout);
	imlib_context_set_image(image_tint);
	imlib_image_set_has_alpha(1);
	imlib_context_set_color(0, 0, 0, tint);
	imlib_image_fill_rectangle(0, hout-26, wout, 26);
	imlib_context_set_image(image_out);
	imlib_blend_image_onto_image(image_tint, 1, 0, 0, wout, hout, 0, 0, wout, hout);
        imlib_save_image(argv[5]);
	return 0;
}

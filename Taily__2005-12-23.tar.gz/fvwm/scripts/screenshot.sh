#!/bin/bash

TIMEOUT=4
NOW=`date '+%Y%m%d-%H%M%S'`
NAME=fvwm${NOW}
EXT=png

cd /home/webroot/screenshots

sleep $TIMEOUT

scrot ${NAME}.${EXT}
convert -resize 200x160 ${NAME}.${EXT} thumbs/${NAME}_thumb.${EXT}

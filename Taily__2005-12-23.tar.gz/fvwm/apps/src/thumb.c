#include <X11/Xlib.h>
#include <Imlib2.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
  Display *display;
  XWindowAttributes windowattr;
  Imlib_Image image, border;
  int windowid, thumbwidth, thumbheight, x, y;
  char *imageformat, *imagepath;
  char *iconpath = NULL;
  float ratio;

  if (argc != 5) {
    puts("Usage: thumb WindowId ThumbSize ThumbFile IconFile");
    return 1;
  }

  if ((display = XOpenDisplay(NULL)) == NULL) return 1;

  sscanf(argv[1], "%x", &windowid);
  sscanf(argv[2], "%d", &thumbwidth);
  imagepath = argv[3];
  imageformat = strrchr(argv[3], '.') + 1;
  if (!strstr(argv[4], "$[") && !strstr(argv[4], argv[3]))
		  iconpath = argv[4];

  XGetWindowAttributes(display, windowid, &windowattr);
  
  x = windowattr.width;
  y = windowattr.height;
  
  if (x > y)
    ratio = (float) thumbwidth / ((float) x);
  else
    ratio = (float) thumbwidth / ((float) y);

  thumbwidth = (int) (x * ratio);
  thumbheight = (int) (y * ratio);

  imlib_context_set_anti_alias(1);
  imlib_context_set_display(display);
  imlib_context_set_visual(DefaultVisual(display,
						  DefaultScreen(display)));
  imlib_context_set_colormap(DefaultColormap(display,
						  DefaultScreen(display)));
  imlib_context_set_drawable(windowid);

  image = imlib_create_image_from_drawable((Pixmap)0, 0, 0, x, y, 1);
  imlib_context_set_image(image);
  image = imlib_create_cropped_scaled_image(0, 0, x, y, thumbwidth, thumbheight);

  if (iconpath) {
    Imlib_Image icon;
    icon = imlib_load_image(iconpath);
    imlib_context_set_image(icon);
    int icon_x = imlib_image_get_width();
    int icon_y = imlib_image_get_height();
    imlib_context_set_image(image);
    imlib_blend_image_onto_image(icon, 0,
					0, 0, icon_x, icon_y,
					0, 0, icon_x, icon_y);
  }
  
/*  border = imlib_create_image(thumbwidth+2, thumbheight+2);
  imlib_context_set_image(border);
  imlib_context_set_color(0, 0, 0, 255);
  imlib_image_fill_rectangle(0, 0, thumbwidth+2, thumbheight+2);
  imlib_context_set_image(border);
  imlib_blend_image_onto_image(image, 0,
				  0, 0, thumbwidth, thumbheight,
				  1, 1, thumbwidth, thumbheight);
  
  imlib_context_set_image(border);*/
  imlib_context_set_image(image);
  imlib_image_set_format(imageformat);
  imlib_save_image(argv[3]);

  fprintf(stdout, "WindowStyle IconOverride, Icon %s\n", argv[3]);
  return 0;
}

// ------------------------------------------------------
// myresize.cxx
// takes in pointer.wx, pointer.wy, w.width, and w.height
// from fvwm, then prints out a command to resize
// to nearest corner/edge of window
// -------------------------------------------------------

// arguments are passed in through stdin in this order:
//    pointer.wx, pointer.wy, w.width, w.height

#include <stdio.h>
#include <stdlib.h>

//#define DEBUG

// pointer.wx, pointer.wy, w.width, w.height:
int pwx, pwy, width, height;

enum vertical { TOP, MIDDLE, BOTTOM };
enum horizontal { LEFT, CENTER, RIGHT };

// calculate distance between pwx, pwy and x,y
// where x and y are per_x% and per_y% across the width and height of the window
// don't bother square rooting, since we're just comparing them
int distance(int per_x, int per_y) {

  int x = per_x * width / 100;
  int y = per_y * height / 100;

  int dx = x - pwx;
  int dy = y - pwy;

  return dx*dx + dy*dy;
}

int main() {

  // read variables in from standard in
  scanf("%i %i %i %i", &pwx, &pwy, &width, &height);

#ifdef DEBUG
  printf("echo %i %i %i %i\n", pwx, pwy, width, height);;
#endif

  // calculate distance to each edge and corner from pointer
  // northeast, north, northwest, west, east, etc....

  int d_NW = distance(0,0);
  int d_W = distance(0,50);
  int d_SW = distance(0,100);

  int d_N = distance(50,0);
  int d_S = distance(50,100);

  int d_NE = distance(100,0);
  int d_E = distance(100,50);
  int d_SE = distance(100,100);

  char* direction;
  char* cursor_style;

  int min_distance = d_NW;
  direction = "NW";
  cursor_style = "top_left_corner";
 
  if (d_NE < min_distance) {
    min_distance = d_NE;
    direction = "NE";
    cursor_style = "top_right_corner";
  }

  if (d_SW < min_distance) {
    min_distance = d_SW;
    direction = "SW";
    cursor_style = "bottom_left_corner";
  }

  if (d_SE < min_distance) {
    min_distance = d_SE;
    direction = "SE";
    cursor_style = "bottom_right_corner";
  }
 
  if (d_W < min_distance/2) {
    min_distance = d_W;
    direction = "W";
    cursor_style = "left_side";
  }

  if (d_E < min_distance/2) {
    min_distance = d_E;
    direction = "E";
    cursor_style = "right_side";
  }

  if (d_S < min_distance/2) {
    min_distance = d_S;
    direction = "S";
    cursor_style = "bottom_side";
  }

  if (d_N < min_distance/2) {
    min_distance = d_N;
    direction = "N";
    cursor_style = "top_side";
  }


  printf("CursorStyle RESIZE %s\n", cursor_style);
  printf("Resize direction %s\n", direction);
  printf("CursorStyle RESIZE\n");
}

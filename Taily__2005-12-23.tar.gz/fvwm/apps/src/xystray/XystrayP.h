/* xystray
 * Copyright (c) 2005 Lukasz Stelmach.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef _XWINTRAYP_H
#define _XWINTRAYP_H

#include "Xystray.h"
#include <X11/Xos.h>
#include <X11/IntrinsicP.h>
#include <X11/CoreP.h>

typedef struct {
	Atom selection_atom;	/* _NET_SYSTEM_TRAY_S0 */
	Atom opcode_atom;	/* _NET_SYSTEM_TRAY_OPCODE */
	Atom data_atom;		/* _NET_SYSTEM_TRAY_MESSAGE_DATA */
	Atom xembed_atom;	/* _XEMBED */
	Atom xembedi_atom;	/* _XEMBED_INFO */
	Window comm;		/* XGetSelection */
	Window* iconwindows;	/* tablica ikon, alokowana w initialize */
	Dimension iconsfree;	/* ilo�� dost�pnych miejsc */
	Dimension iconmax;	/* ilo�� */
	Dimension iconrows;	/* rz�dy */
	Dimension iconcols;	/* kolumny */
	Dimension iconpadding;	/* odst�py */
	Dimension iconsize;	/* rozmiary */
	Boolean vertical;	/* orientacja */
	Boolean multiple;	/* oddzielne okna */
} XystrayPart;

typedef struct _XystrayRec{
	CorePart core;
	XystrayPart xystray;
} XystrayRec;

typedef struct {
	int dummy;
} XystrayClassPart;

typedef struct _XystratClassRec {
	CoreClassPart core_class;
	XystrayClassPart xystray_class;
} XystrayClassRec;

extern XystrayClassRec xystrayClassRec;

#endif /* _XWINTRAY_H */

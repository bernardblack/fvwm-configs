#!/usr/bin/perl -w

( $menu, $path ) = @ARGV;

$bg_command = "feh --bg-center";

foreach $file (<$path/*>) {

    $name = basename( $file );

    print "AddToMenu $menu \"$name\" Exec $bg_command \"$file\"\n";
}

#print "AddToMenu $menu \"XPlanet\" Exec xplanetbg --projection mercator " .
#      "-cloud_image /home/damien/.xplanet/clouds_2002.jpg " .
#      "-wait 600 -markers -blend -markerfile /home/damien/.xplanet/earth\n"

sub basename {
    my $name      = $_[0];

    # On garde uniquement le nom du fichier

    $name =~ s/.*\///;

    # On supprime l'extension

    $name =~ s/(.jpg|.png)//;

    return $name;
}

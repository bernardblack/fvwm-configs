#!/usr/bin/perl -Tw

use strict;
use Calendar::Simple;

my @months = qw(Janvier F�vrier Mars Avril Mai Juin Jullet Ao�t
  Septembre Octobre Novembre D�cembre);

my $mon = shift || (localtime)[4] + 1;
my $yr  = shift || ( (localtime)[5] + 1900 );

my @month = calendar( $mon, $yr, 1 );

print "$months[$mon -1] $yr\n";

print "Lun Mar Mer Jeu Ven Sam Dim\n";

foreach (@month) {
    print map { $_ ? sprintf "%3d ", $_ : '    ' } @$_;
    print "\n";
}


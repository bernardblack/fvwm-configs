#!/usr/bin/perl -w
# checkmail_lin.pl
# Copyright (C) 2002 Damien FAURITE
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

use strict;
use Net::POP3;

#use AppConfig qw(:expand :argcount);

my $prog_name   = "Checkmail";
my $checkmailrc = "checkmailrc";
my $message     = "";
my $image;
my $image_name;

#my $config = AppConfig->new(
#    'user' => { ARGCOUNT => 1 },
#    'pass' => { ARGCOUNT => 1 },
#    'host' => { ARGCOUNT => 1 }
#);

#$config->file($checkmailrc);

#my $user = $config->user();
#my $pass = $config->pass();
#my $host = $config->host();

my $user = "*****";
my $pass = "*****";
my $host = "pop";

my $pop = Net::POP3->new( $host, Timeout => 60 );

if ( defined($pop) ) {

    my $num = $pop->login( $user, $pass );

    if ( !defined($num) ) {
        $message = "Erreur";
    }
    elsif ( $num == 0) {
    	$message = "0 mail";
    }
    else {
        $message = "$num mail";
    }

    $pop->quit();

}
else {
    $message = "Erreur";
}

print $message . "\n";


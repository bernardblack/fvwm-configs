#!/bin/bash

cd ../icons

for j in *;
do
	cd $j
	mkdir highlight
	mkdir shade
	echo "CD into $j"
	for i in *;
	do
 	 echo "		Converting $i"
  	 convert -gamma 2 $i highlight/$i;
	 convert -gamma 0.3 $i shade/$i;
	done
	cd ..
done 


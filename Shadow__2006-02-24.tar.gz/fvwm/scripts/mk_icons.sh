#!/bin/bash

cd ../icons

for i in *;
do
  echo "Converting $i"
  convert $i -resize 16x16 16x16/$i;
  convert $i -resize 24x24 24x24/$i;
  convert $i -resize 48x48 48x48/$i;
  convert $i -resize 35x35 35x35/$i;
  convert $i -resize 40x40 40x40/$i;
done


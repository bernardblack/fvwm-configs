#!/bin/bash
###### >>								<< ######
#										#
#	File: startconky.sh							#
#	By sabmann								#
#	E-mail\Gaim(msn): rekennewsab [at] hotmail [dot] com			#
#										#
#	This sh file is executed by startstop in ~/.fvwm/include		#
#										#
############## >>						<< ##############


killall torsmo > /dev/null 2>&1

for I in ${HOME}/.conky/*.conkyrc
do
	conky -c $I &
done

#!/usr/bin/env python

# Openbox3 ET Servers pipe-menu
# Version 0.1
# http://syscrash2k.hopto.org/stuff/openbox-pipe-et/et-menu.tar.bz2

# Usage:
# Put the file 'qstat-template' in the directory '~/.config/openbox',
# so that the script can find it.
#
# Put an entry in your ~/.config/openbox/menu.xml like this:
# <menu id="et" label="enemy-t" execute="~/projects/openbox-et-menu/et-menu.py" />
# And inside <menu id="root-menu" label="openbox">, add this somewhere (wherever you want it on your menu)
# <menu id="et" />

from commands import *
import string

# Edit this line to whichever servers you wish to monitor! (space separated)
servers = "213.202.214.239:27975 213.239.209.10:28000 66.246.72.187:27960 62.4.74.236:30400 62.75.224.195:27960 217.20.121.38:27960 217.20.113.238:28004 217.20.117.151:37150 218.228.182.3:27961 213.202.214.239:27975"

server = string.split(servers, " ")
template = "~/.config/openbox/qstat-template"
qstat = "/usr/bin/qstat -nocfg -sort l -Ts " + template + " -nh -timeout 3 -default rws "
output = getoutput(qstat + servers)
output = string.split(output, "\n")
x = 0

#print "DestroyMenu TceliteServers"
#print "AddToMenu TceliteServers"

for i in output:
	server_host = server[x]
	print " +  \"" + i + "%32x32/et.png\" Exec exec x.tc-elite +connect  "+ server_host +" "
	x += 1

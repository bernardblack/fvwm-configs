#!/usr/bin/perl

use strict;
use warnings;

use File::Find::Rule;
use File::Spec;

@ARGV == 2 or die "Usage: playlist.pl [mp3dir] [outputdir]\n";

my ($mp3dir, $outputdir) = @ARGV;


my @dirs = File::Find::Rule->directory->maxdepth(1)->in($mp3dir);

foreach my $dir (@dirs) {
	my @files = File::Find::Rule->file->name('*.mp3', '*.ogg')->in($dir);

	my $playlist = "[playlist]\nNumberOfEntries=" . scalar @files . "\n";
	my $counter = 1;
	foreach my $file (@files) {
		$playlist .= "File" . $counter++ . "=$file\n";
	}

	(my $filename = $dir) =~ s|.*/||;
	$filename = File::Spec->catfile($outputdir, "$filename.pls");

	open PLAYLIST, ">", $filename or die "Can't open file for writing: $!";
	print PLAYLIST $playlist;
	close PLAYLIST;
}


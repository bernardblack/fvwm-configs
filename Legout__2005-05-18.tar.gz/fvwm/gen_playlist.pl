#!/usr/bin/perl

use warnings;
use strict;

use File::Find::Rule;
use File::Spec;

use File::Basename;

use Getopt::Long;

Getopt::Long::Configure ("bundling");

my %arg = ();
GetOptions(
	"help" => \$arg{"help"},
	"input|i=s" => \$arg{"input"},
	"output|o=s" => \$arg{"output"},
	"type|t=s" => \$arg{"type"},
	"exclude|x=s" => \$arg{"exclude"},
	"m3u|m" => \$arg{"m3u"},
	"safe|s" => \$arg{"safe"},
	"pls|p" => \$arg{"pls"}
);

if($arg{"help"}) {
	print <<"HELP";
Usage: gen_playlist.pl --input DIR --output DIR ...

    -i DIRECTORY                A directory where music files are found.
        --input=DIRECTORY

    -o DIRECTORY                A directory where playlists will be
        --output=DIRECTORY      created; defaults to the current directory.

    -t TYPE1,TYPE2,...          A list of file extensions to include in the 
        --type=TYPE1,TYPE2,...  playlists.  Defaults to mp3,ogg.

    -x REGEX                   Ignore directories that match REGEX.
        --exclude=REGEX

    -s, --safe                  Safe; don't overwrite files if they exist.
                                (Yes, this script overwrites by default.)

    -p, --pls                   Generate playlists in PLS format.
    -m, --m3u                   Generate playlists in M3U format.

    --help                      Display this help message.

    The script will generate M3U if no playlist format is specified.  
    Use -p if you want PLS instead. Use -m -p if you want both at once.

HELP

	exit;
}


defined $arg{"input"} or print "Not enough arguments.  \nSee `gen_playlist.pl --help`.\n" and exit;

$arg{"type"} ||= 'mp3,ogg';
$arg{"output"} ||= '.';

my $dir_rule = File::Find::Rule
	->directory
	->maxdepth(1)
	->mindepth(1)
;

my @dirs = ( 
	$arg{"exclude"} 
		? $dir_rule->not( File::Find::Rule->name(qr/$arg{"exclude"}/))->in($arg{"input"} ) 
		: $dir_rule->in($arg{"input"})
);

my @types = map {"*.$_"} split ",", $arg{"type"};

foreach my $dir (@dirs) {

	my @files = map {File::Spec->rel2abs($_)} File::Find::Rule->extras({ follow => 1 })->file->name(@types)->in($dir);

	my $plname = File::Spec->catfile( $arg{"output"}, basename($dir));

	my ($file, $playlist);

	if($arg{"m3u"} || (! defined $arg{"m3u"} && ! defined $arg{"pls"}) ) {

		if($arg{"safe"} && -e "$plname.m3u") {
			print "EXISTS : $plname.m3u\n";
		} else {
			$playlist = "";
			foreach $file (@files) {
				$playlist .= "$file\n";
			}

			if($playlist) {
				open M3U, ">", "$plname.m3u" or die "Can't open file for writing: $!";
				print M3U $playlist;
				close M3U;

				print "Created: $plname.m3u\n"

			} else {
				print "EMPTY  : $plname.m3u\n";
			}
		}
	}

	if($arg{"pls"}) {

		if($arg{"safe"} && -e "$plname.pls") {
			print "EXISTS : $plname.pls\n";
		} else {
			$playlist = "[Playlist]\nNumberOfEntries=" . scalar @files . "\n";
			my $counter = 1;
			foreach $file (@files) {
				$playlist .= "File" . $counter++ . "=$file\n";
			}

			if($playlist =~ /File/s) {
				open PLS, ">", "$plname.pls" or die "Can't open file for writing: $!";
				print PLS $playlist;
				close PLS;
				print "Created: $plname.pls\n"

			} else {
				print "EMPTY  : $plname.pls\n";
			}
		}
	}
	
}	

__END__

    Example:
        Look in ~/music for music; store playlists in ~/playlists:

        gen_playlist.pl -i ~/music -o ~/playlists
        
    More confusing example:
        Generate playlists in M3U and PLS formats; look in ~/music for music;
        skip directories called "Playlists" when looking for music; store 
        playlists in ~/music/Playlists; don't overwrite playlists that already
        exist with the same filename; only include MP3 files and WAV files:
	 	
        gen_playlist.pl -mp -t mp3,wav -i ~/music -o ~/music/Playlists -x 'Playlists'



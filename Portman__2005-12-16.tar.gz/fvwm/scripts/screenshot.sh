#!/bin/bash

DATE=`date '+%Y%m%d%M%S'`
FNAME=fvwm${DATE}.png
USERNAME="portman"
PASS="URPASSWORD"
SERVER="en0x.net"
DELAY="5"
QUALITY="60"

cd /home/portman/.fvwm/screens
scrot -d ${DELAY} -q ${QUALITY} ${FNAME}
lftp -u ${USERNAME},${PASS} -e "cd public_html/GALERIE/SCREENS && put ${FNAME} && quit" ${SERVER} 


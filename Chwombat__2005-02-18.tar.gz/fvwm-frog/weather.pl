#!/usr/bin/perl

use warnings;
use strict;

use LWP::Simple;

print qq|+ "Need a zip code, chief." Title\n| and exit unless $ARGV[0];

my $content = get("http://www.w3.weather.com/weather/local/$ARGV[0]");

$ARGV[1] = $ARGV[1] || "F";

print qq|+ "Invalid zip code." Title\n| and exit if $content =~ /No items found\./s;

$content =~ s/.*<!-- begin loop -->(.*)<!-- end loop -->.*/$1/s;

my @day = split /<TR>/, $content;

shift @day;

if($ARGV[1] =~ /c/i) {
	print qq|+ "%blank.png% Date\tHigh/Low (| . chr(186) . qq|C)\tPrecip" Title\n|;
} else {
	print qq|+ "%blank.png% Date\tHigh/Low (| . chr(186) . qq|F)\tPrecip" Title\n|;
}

my ($day, $date, $img, $temp, $precip);
my $tomorrow;

foreach $_ (@day) {
	($day) = /(\w+)<\/A>/s;
	($date) = /<BR> (.+?)</s;
	
	($img) = /(\d+)\.gif/s;
	$img .= '.png';

	($temp) = /<B>(.*?)<\/B>/s;
	$temp =~ s/&deg;/chr(186)/eg;
	if($ARGV[1] =~ /c/i) {
		$temp =~ s|(\d+)|sprintf "%d", ($1 - 32) * 5 / 9|eg;
	}

	($precip) = /(\d+ %)/;

	if($day =~ /Today|Tonight/) {
		print qq|+ "%$img% $day\t$temp\t$precip%" Nop\n|;
		$tomorrow = 1;
	} elsif($tomorrow) {
		print qq|+ "%$img% Tomorrow\t$temp\t$precip%" Nop\n|;
		undef $tomorrow;
	} else {
		print qq|+ "%$img% $date\t$temp\t$precip%" Nop\n|;
	}

}




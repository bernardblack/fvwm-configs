#!/bin/bash

echo $1 > ~/.fvwm/wallpaper
Esetroot $1


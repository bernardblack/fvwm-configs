#!/usr/bin/perl

use strict;
use warnings;

use Mail::IMAPClient;

my $imap = Mail::IMAPClient->new(
	Server => 'localhost',
	User => 'USERNAME',
	Password => 'PASSWORD',
) or print "+ \"Error: $!\" Nop\n";

foreach (sort $imap->folders) {
	printf "+ \"%s\t(%d/%d) %s\" Exec exec evolution\n", $_, $imap->unseen_count($_), $imap->message_count($_), $imap->unseen_count($_)? "**" : " " ;
}

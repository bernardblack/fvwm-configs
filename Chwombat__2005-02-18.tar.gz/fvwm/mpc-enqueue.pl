#!/usr/bin/perl

$ARGV[0] =~ s|.*/(.*?).m3u|$1|;
if($ARGV[0]){ exec ("mpc load $ARGV[$0]") }

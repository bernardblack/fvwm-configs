#!/usr/bin/perl

open CPU, "<", "/proc/stat" or die "Can't open /proc/stat for reading: $!";

$time = time;
$_ = <CPU>;

/^cpu\s+(\d+) (\d+) (\d+) (\d+)/;

$total = ($1 + $2 + $3);

sleep 1;

while(1) {
	seek (CPU, 0, 0) or die "Can't seek: $!";

	$old_time = $time;
	$time = time;
	$_ = <CPU>;

	$delta = $time - $old_time;
	
	/^cpu\s+(\d+) (\d+) (\d+) (\d+)/;

	#print "##$1",$2,$3,$4,"\n\n";

	$old_total = $total;
	$total = ($1 + $2 + $3);

	$percent = ($total - $old_total) / $delta;

	print $percent, "\n";
	sleep 1;
}

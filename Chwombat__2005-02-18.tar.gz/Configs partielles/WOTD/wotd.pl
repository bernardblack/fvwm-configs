#!/usr/bin/perl

use strict;
use warnings;

use LWP::Simple;

use Text::ASCIITable::Wrap qw{ wrap };

my $wotd = get("http://dictionary.reference.com/wordoftheday/") or die "Couldn't get page: $!";

local $/;
(my $word) = ($wotd =~ /WOTD="(.*?)"/i);
(my $def) = ($wotd =~ /WOTD=.*?-->\s*(?:<b>\s*1.\s*<\/b>\s*)?(.*?)(?:<br>|\n)/is);

unless($_ eq $wotd) {

	print " $word\n";
	print "    ", wrap($def, 46);

}


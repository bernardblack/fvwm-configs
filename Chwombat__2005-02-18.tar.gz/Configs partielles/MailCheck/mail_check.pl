#!/usr/bin/perl

use strict;
use warnings;

use Mail::IMAPClient;

my $imap = Mail::IMAPClient->new(
	Server => 'localhost',
	User => 'USERNAME',
	Password => 'PASSWORD',
) or print "+ \"Error: $!\" Nop\n";

foreach (sort $imap->folders) {
	printf "+ \"%s\t(%d/%d)\t%s\" Exec exec evolution-1.5\n", $_, $imap->unseen_count($_), $imap->message_count($_), $imap->unseen_count($_)?"%newmail_mini.png%":"%blank_mini.png%";
}

__END__

This is a little script that generates an FVWM menu displaying the status of a bunch of IMAP mailboxes.  You need the Perl module Mail::IMAPClient.  The script starts in a top-level IMAP folder and traverses all its subfolders.  You probably don't want to use this with a remote IMAP server, because it'd take forever to load, and it IS a menu, so it should load fast.  If you run a local instance of courier-imap or similar, this works just fine.  Change the command above to whatever your mail app is; I use evolution-1.5.  If your mail app can take a command line argument of a folder to jump to, you can code that into the above very easily, but evolution can't do that.  :(

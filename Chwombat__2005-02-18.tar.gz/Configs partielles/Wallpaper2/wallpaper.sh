#!/bin/bash

convert -scale 1280x1024 $1 ~/.fvwm/wallpaper
composite ~/.fvwm/overlay.png ~/.fvwm/wallpaper ~/.fvwm/wallpaper
Esetroot ~/.fvwm/wallpaper

# All this does is take a wallpaper argument, resize it to 1280x1024, composite an overlay png on top of it, and then set it as the background.  Why in the world would you want to composite an image onto your wallpaper?  Because FVWMButtons doesn't support backgrounds very well.  See my .fvwm2rc for more details.


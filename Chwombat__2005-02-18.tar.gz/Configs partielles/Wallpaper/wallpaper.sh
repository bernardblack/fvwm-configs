#!/bin/bash

Esetroot -scale $1 
echo $1 > ~/.fvwm/current_wallpaper

# Doesn't get much simpler than this.  Write the current wallpaper's filename to a file so FVWM can remember it.

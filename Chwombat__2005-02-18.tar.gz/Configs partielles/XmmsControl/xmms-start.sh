#!/bin/bash
xmms-shell -e 'xmmsexit'
xmms &
sleep 1
xmms-shell -e 'window all hide'

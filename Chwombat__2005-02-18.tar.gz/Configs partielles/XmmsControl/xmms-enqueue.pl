#!/usr/bin/perl

if($ARGV[0]){ exec ("xmms-shell -e 'load $ARGV[0]'") }

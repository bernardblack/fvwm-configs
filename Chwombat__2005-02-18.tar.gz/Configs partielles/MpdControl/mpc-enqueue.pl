#!/usr/bin/perl

$ARGV[0] =~ s|.*/(.*?).m3u|$1|;
if($ARGV[0]){ exec ("mpc load $ARGV[$0]") }

# Pathetically simple bash script.  Takes a filename of a .m3u playlist as an argument, strips the extension and path, and feeds it to mpc.

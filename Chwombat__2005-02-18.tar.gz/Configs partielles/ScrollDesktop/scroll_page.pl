#!/usr/bin/perl


# ScrollDesktop
# This script enables Enlightenment-like page switching, i.e. instead of just switching, the whole screen slides and zooms in various directions.  Useless eye-candy, yes, but I likes it.

use warnings;
use strict;

# Pages are counted starting from 0,0 in the upper left.
my ($cur_x, $cur_y, $des_x, $des_y) = @ARGV;

# This controls the speed of the animation.  
# Bigger step = less smooth but faster.
my $step = 4;

my $delta_x = ($des_x - $cur_x) * $step;
my $delta_y = ($des_y - $cur_y) * $step;

# To clarify: 1280x1024 = (64*20)x(64*16), that's where the numbers below come from.  (And a $step is factored out to let you tweak things more easily with less math.)  
# This is going to depend on your screen resolution.  If you don't use 1280x1024, you need to change the numbers below.  There might be a cool way to auto-detect and generate these numbers, but it's beyond me.  The speed and smoothness of the animation is likely highly dependent on your graphics card, CPU, etc. etc. anyways.  So you're going to need to mess with these numbers.

# NOTE: 1280x1024 is a 5:4 ratio.  All other major screen resolutions I can think of are 4:3.  Happy calculating.  :)

# NOTE ALSO: The FVWM Scroll command can also take percentages instead of pixel values.  You may be tempted to use this.  However unless your screen resolution is evenly divisible by 100, you're not going to end up scrolling to exact page margins; you're going to be a few pixels off each time.

for(1..(64/$step)) { print "Scroll " . $delta_x * 20 . "p " . $delta_y * 16 . "p\n" }


#!/usr/bin/perl

# This uses Yahoo's weather site to get a mere 5 days of weather data.  
# Darn you, weather.com!  How dare you change the format of your own site.
# I'll write a better scripts once I feel like bothering to parse something more complex.

# This script takes as an argument a code.  Look up your city on Yahoo's weather site
# and look and see what the code is in the URL.  Or use your zip code.

use warnings;
use strict;

use LWP::Simple;

print qq|+ "Need a zip code, chief." Title\n| and exit unless $ARGV[0];

my $content = get("http://weather.yahoo.com/forecast/$ARGV[0].html");

$ARGV[1] = $ARGV[1] || "F";

print qq|+ "Invalid zip code." Title\n| and exit if $content =~ /No items found\./s;

$content =~ s/.*FORECAST(.*)END FORECAST.*/$1/s;

my @day = ($content =~ m|<td width="\d+%" align="center"><font face="Arial" size="2"><b>(.*?)</b>|g);
pop @day;

my @img = ($content =~ m|<img src="http://us.i1.yimg.com/us.yimg.com/i/us/we/52/(.*?)" width="52" height="52" alt=|g);
s/gif/png/ foreach @img;

my @high = ($content =~ m|High:.*?(\d+)&deg;|g);
my @low = ($content =~ m|Low:.*?(\d+)&deg;|g);
	
if($ARGV[1] =~ /c/i) {
	print qq|+ "%blank.png% Date\tHigh/Low (|  . qq|C)" Title\n|;
} else {
	print qq|+ "%blank.png% Date\tHigh/Low (|  . qq|F)" Title\n|;
}

my ($day, $date, $img, $temp, $precip);
my $tomorrow;

foreach (0..$#day) {

	print qq|+ "%$img[$_]% $day[$_]\t$high[$_] / $low[$_]" Nop\n|;

}


#!/bin/bash

#to set a debug output file, set suffix to 2>&1>>/tmp/debug.txt or similar
URL="http://weather.yahoo.com/forecast/USNY1242.html"
FETCHED=fetched
CONVERTED=converted
MENU=$1

# No changes needed beneath this line #
BASE=`dirname $0`
FETCHED=$BASE/$FETCHED
CONVERTED=$BASE/$CONVERTED
FETCH_COMMAND="wget -P $FETCHED $URL"

MONTH=`date +%m`
DAY=`date +%d`
DAY_TEXT_0=Today
DAY_TEXT_1=Tomorrow
DAY_TEXT_2=`date -d $MONTH/$(($DAY+2)) +%A`
DAY_TEXT_3=`date -d $MONTH/$(($DAY+3)) +%A`
DAY_TEXT_4=`date -d $MONTH/$(($DAY+4)) +%A`
DAY_TEXT_5=`date -d $MONTH/$(($DAY+5)) +%A`
COUNT=0


function fetch_data(){
   rm $FETCHED/`echo $URL | rev | cut -f1 -d / | rev` 2>/dev/null
   $FETCH_COMMAND 2>/dev/null
}

function get_line(){
   local LINE=$1
   local FILE=$2
   echo `head -n $LINE $FILE | tail -n 1`
}

function determine_file_name(){
   local IN_URL=$1
   echo `echo $IN_URL | rev | cut -f1 -d/ | rev`
}

function make_menu_entry(){
   local DESC_TEXT=
   if [ $COUNT -eq 0 ]; then
      DESC_TEXT=$DAY_TEXT_0
   elif [ $COUNT -eq 1 ]; then
      DESC_TEXT=$DAY_TEXT_1
   elif [ $COUNT -eq 2 ]; then
      DESC_TEXT=$DAY_TEXT_2
   elif [ $COUNT -eq 3 ]; then
      DESC_TEXT=$DAY_TEXT_3
   elif [ $COUNT -eq 4 ]; then
      DESC_TEXT=$DAY_TEXT_4
   elif [ $COUNT -eq 5 ]; then
      DESC_TEXT=$DAY_TEXT_5
   fi
   echo AddToMenu $MENU "*$CONVERTED/$@*$DESC_TEXT" Nop
   COUNT=$(($COUNT+1))
}

function build_menu(){
   #open the fetched file
   local FILE=`determine_file_name $URL`
   FILE=$FETCHED/$FILE

   #loop through each line of the file between the forecast tags
   local FORECAST_START=`grep -n '\- FORECAST \-' $FILE| cut -f1 -d:` 
   local FORECAST_STOP=`grep -n '\- END FORECAST \-' $FILE| cut -f1 -d:`
   local CURRENT=$FORECAST_START


   while [ $CURRENT -lt $FORECAST_STOP ]; do
      CURRENT=$(($CURRENT+1))
      local LINE=`get_line $CURRENT $FILE`
      local IMG_LINE=`echo $LINE | grep img`

      #if the line contains an img tag, then it's an image we may need to fetch
      if [ "x$IMG_LINE" != "x" ]; then
         local IMG_SRC=`echo $IMG_LINE | cut -f2 -d= | cut -f2 -d\"`
         #fetch the image to the fetched folder
         #but only if it doesn't already exist there
         local LOCAL_NAME=`echo $IMG_SRC | rev | cut -f1 -d/| rev`
         local NEW_NAME=`echo $LOCAL_NAME | rev | cut -f2 -d . | rev`
         if [ ! -f "$CONVERTED/$NEW_NAME" ]; then
            NEW_NAME=$NEW_NAME.png
            wget -P $FETCHED $IMG_SRC 2>/dev/null
            #conver the fetched image to something fvwm can deal with
            convert $FETCHED/$LOCAL_NAME $CONVERTED/$NEW_NAME 2>/dev/null
            #remove the old images
            rm $FETCHED/$LOCAL_NAME 2>/dev/null
         fi
         make_menu_entry $NEW_NAME
      else
         #drop the tags from the line and see if it is plain text
         #if it's plain text, save it as the title
         #local TEXT=`extract_text $LINE`
         #if [ "x$TEXT" != "x" ]; then
         #   echo $TEXT
         #fi
         echo 2>&1>/dev/null
      fi
   done
}

build_menu

#include <X11/Xlib.h>
#include <Imlib2.h>
#include <stdio.h>
#include <string.h>

/**
 * This is some refactored code originally by Sascha then modified by pem then 
 * modified by me on the fvwm forum:
 * fvwm.lair.be
 */

class Thumbnailer
{
   public:
      /**
       * Create a thumbnailer, initial state is invalid
       */
      Thumbnailer();
      
      /**
       * Responsible for parsing command line arguments and setting validity
       */
      void parseArguments(int count, char ** arguments);

      /**
       * Reports the validity of the iconifier - only valid iconifiers can iconify
       */
      bool isValid();

      void createIcon();

   private:
      int m_WindowId, m_ThumbWidth, m_ThumbHeight;
      bool m_Valid, m_HasIcon;
      char *m_ImageFormat, *m_ImagePath;
      char *m_IconFormat, *m_IconPath;

      /**
       * Initialize imlib
       */
      void setup_imlib(Display * display);

      /**
       * Create the image to be converted to an icon
       */
      Imlib_Image create_image(XWindowAttributes windowattr);

      /**
       * Compose the icon to the image
       */
      void compose_icon(Imlib_Image image);
};

int main(int argc, char **argv) 
{

   Thumbnailer i;

   i.parseArguments(argc,argv);
   if(! i.isValid() )
   {
      puts("Usage: thumbnail WindowId ThumbWidth ThumbFile [IconFile]");
      return 1;
   }

   i.createIcon();
   if(!i.isValid())
      return 1;

   /*   fprintf(stdout, "WindowStyle IconOverride, Icon %s\n", argv[3]); */
   return 0;
}

/**
* Create an iconifier, initial state is invalid
*/
Thumbnailer::Thumbnailer()
{
   m_Valid = false;
   m_HasIcon = false;
}

/**
* Responsible for parsing command line arguments and setting validity
*/
void Thumbnailer::parseArguments(int count, char ** arguments)
{
   if ( count >= 4 ) 
      m_Valid = true;
   else
      return;

   sscanf(arguments[1], "%x", &m_WindowId);
   sscanf(arguments[2], "%d", &m_ThumbWidth);
   m_ImagePath = arguments[3];
   m_ImageFormat = strrchr(arguments[3], '.');

   if( count == 5 )
   {
      m_IconPath = arguments[4];
      m_IconFormat = strrchr(arguments[4], '.');
      m_HasIcon = true;
   }
}

/**
 * Reports the validity of the iconifier - only valid iconifiers can iconify
 */
bool Thumbnailer::isValid()
{
   return m_Valid;
}

void Thumbnailer::createIcon()
{
   XWindowAttributes windowattr;
   Display *display;
   Imlib_Image image;

   if( m_Valid == false) return;
   if ( (display = XOpenDisplay(NULL)) == NULL )
   {
      m_Valid = false;
      return;
   }

   XGetWindowAttributes(display, m_WindowId, &windowattr);

   m_ThumbHeight = (int)((float)windowattr.height / ((float)windowattr.width/(float)m_ThumbWidth));

   setup_imlib(display);

   image = create_image(windowattr);
   
   if( m_HasIcon )
      compose_icon(image);

   imlib_context_set_image(image);
   imlib_image_set_format(m_ImageFormat + 1);
   imlib_save_image(m_ImagePath);
}

/**
 * Initialize imlib
 */
void Thumbnailer::setup_imlib(Display * display)
{
   imlib_context_set_anti_alias(1);
   imlib_context_set_display(display);
   imlib_context_set_visual(DefaultVisual(display, DefaultScreen(display)));
   imlib_context_set_colormap(DefaultColormap(display, DefaultScreen(display)));
   imlib_context_set_drawable(m_WindowId);
}

/**
 * Create the image to be converted to an icon
 */
Imlib_Image Thumbnailer::create_image(XWindowAttributes windowattr)
{
   Imlib_Image image;
   int width = 4 * m_ThumbWidth, height = 4 * m_ThumbHeight;
   if ( width >= windowattr.width || height >= windowattr.height )
   {
      image = imlib_create_image_from_drawable((Pixmap)0, 0, 0,
      windowattr.width, windowattr.height, 1);
      imlib_context_set_image(image);
      image = imlib_create_cropped_scaled_image(0, 0, windowattr.width, windowattr.height,
      m_ThumbWidth, m_ThumbHeight);
   } else {
      image = imlib_create_scaled_image_from_drawable((Pixmap)0, 0, 0,
      windowattr.width, windowattr.height, width, height, 1, 1);
      imlib_context_set_image(image);
      image = imlib_create_cropped_scaled_image(0, 0, width, height,
      m_ThumbWidth, m_ThumbHeight);
   }
   return image;
}

/**
 * Compose the icon to the image
 */
void Thumbnailer::compose_icon(Imlib_Image image)
{
   Imlib_Image icon = imlib_load_image(m_IconPath);
   imlib_context_set_image(icon);
   int w = imlib_image_get_width();
   int h = imlib_image_get_height();
   imlib_context_set_image(image);
   imlib_blend_image_onto_image( icon, 0,
   0, 0, w, h, m_ThumbWidth-w, m_ThumbHeight-h, w, h);
}
